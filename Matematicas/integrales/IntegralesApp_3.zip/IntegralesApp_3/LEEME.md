# 📱 Integral Trainer — App Android en Kotlin

Versión app de tus dos cuestionarios web (index.php y trigonometricas.php).
Todo funciona **sin internet**: las preguntas y respuestas van dentro de la app.

## Cómo se usa la app

1. Pantalla inicial: eliges cuestionario
   - 📘 Integrales Básicas (19 preguntas)
   - 📗 Integrales Trigonométricas (10 preguntas)
2. Se muestra **una pregunta por pantalla**
3. Escribes tu respuesta → botón **Verificar** → te dice ✔ correcto o ✘ incorrecto
4. Botón **Ver solución** si te rindes (igual que tu "mostrar_solucion")
5. **Siguiente ➜** para avanzar, **⬅ Anterior** para regresar
6. Al finalizar te muestra cuántas respondiste bien

## Cómo compilar (3 pasos)

1. **Descomprime** el ZIP donde quieras (por ejemplo en Escritorio)
2. Abre **Android Studio** → **File → Open** → selecciona la carpeta `IntegralesApp`
   (la que contiene `settings.gradle.kts`)
3. Espera a que sincronice (primera vez tarda unos minutos) y luego:
   - **Build → Build Bundle(s) / APK(s) → Build APK(s)**
   - La APK queda en: `app/build/outputs/apk/debug/app-debug.apk`

Para probarla: **Run ▶** con tu celular conectado por USB (con Depuración USB activada)
o con un emulador.

## Barra de símbolos matemáticos

Sobre el campo de respuesta hay botones estilo Symbolab:

| Botón | Inserta | El cursor queda… |
|---|---|---|
| ▭⁄▭ | `\frac{}{}` | dentro del numerador |
| x^▭ | `^{}` | dentro del exponente |
| √▭ | `\sqrt{}` | dentro de la raíz |
| ( ) | `()` | dentro |
| \| \| | `\|\|` | dentro |
| Ln\| \| | `Ln\|\|` | dentro de las barras |
| +C | agrega `+C` al final | al final |
| ⇥ | salta al siguiente hueco (tras `}`, `\|` o `)`) | |

## Validación matemática (estilo Symbolab)

La app valida en dos pasos:

1. **Coincidencia exacta** con la lista `aceptadas` (como tu PHP).
2. Si no coincide, hace **verificación matemática**: evalúa numéricamente la
   respuesta y la solución en muchos puntos aleatorios. Si valen lo mismo, es
   correcta. Por eso `\frac{1}{3x^{-3}}+C`, `x^3/3+C` y `\frac{x^3}{3}+C` se
   aceptan todas sin listarlas a mano. El `+C` sigue siendo obligatorio.

Soporta: fracciones, potencias, raíces, valor absoluto, sen/cos/tan/sec/csc/cot,
ln, multiplicación implícita (3x, 2(x+1)…) y paréntesis anidados.

## Cómo escribir las respuestas en el celular

Acepta las mismas respuestas de tu web **y también** formas más fáciles de
escribir en el teléfono (no importan mayúsculas ni espacios):

| Web (LaTeX) | También vale en la app |
|---|---|
| `\frac{x^4}{4}+C` | `x^4/4+C` |
| `\frac{-1}{2x^2}+C` | `-1/(2x^2)+C` |
| `-Cosx+C` | `-cos(x)+c` |
| `Ln|Secx|+C` | `ln|sec(x)|+c` |

## Dónde editar las preguntas

Todo está en **un solo archivo**:
`app/src/main/java/com/integrales/Quiz.kt`

Cada pregunta tiene 3 partes:
```kotlin
Pregunta(
    "∫ sen(x) dx",                       // lo que se muestra
    listOf("-Cosx+C", "-Cos(x)+C"),      // respuestas aceptadas
    "−Cos(x) + C"                        // solución que se muestra
),
```
Para agregar más cuestionarios (segundo.php, tercero.php, etc.) solo copia el
mismo patrón y agrega un botón en `MainActivity`.
