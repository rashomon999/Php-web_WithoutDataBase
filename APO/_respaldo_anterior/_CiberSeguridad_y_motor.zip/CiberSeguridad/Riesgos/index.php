<?php
/* ==========================================================================
   CiberSeguridad / Riesgos  —  NIST, amenazas, riesgo y ataques
   Fuente: notas_2.pdf (preguntas 1 a 8)
   ========================================================================== */

require_once __DIR__ . '/../motor.php';

$SOLUCIONES = [
    /* --- las cinco funciones del NIST, en orden --- */
    1  => ['identificar', 'identify'],
    2  => ['proteger', 'protect'],
    3  => ['detectar', 'detect'],
    4  => ['responder', 'respond'],
    5  => ['recuperar', 'recover'],
    6  => ['gobernar', 'govern'],

    /* --- que hace cada funcion --- */
    7  => ['identificar', 'identify'],
    8  => ['proteger', 'protect'],
    9  => ['detectar', 'detect'],
    10 => ['responder', 'respond'],
    11 => ['recuperar', 'recover'],

    /* --- agentes de amenaza --- */
    12 => ['amigables', 'amigable', 'friendly'],
    13 => ['no amigables', 'no amigable', 'unfriendly'],
    14 => ['naturales', 'natural'],

    /* --- riesgo --- */
    15 => ['riesgo inherente', 'inherent risk', 'inherente'],
    16 => ['riesgo residual', 'residual risk', 'residual'],

    /* --- atributos del ataque --- */
    17 => ['vector de ataque', 'attack vector', 'vector'],
    18 => ['carga util', 'payload', 'carga'],
    19 => ['vulnerabilidad', 'vulnerability'],
    20 => ['objetivo', 'target'],
    21 => ['vector de entrada', 'ingress vector', 'ingress'],
    22 => ['vector de salida', 'egress vector', 'egress'],

    /* --- malware y ataques --- */
    23 => ['virus'],
    24 => ['gusano', 'worm'],
    25 => ['troyano', 'trojan horse', 'trojan', 'caballo de troya'],
    26 => ['ransomware'],
    27 => ['spyware'],
    28 => ['phishing'],
    29 => ['denegacion de servicio', 'dos', 'denial of service'],

    /* --- servicios --- */
    30 => ['autenticacion', 'authentication'],
    31 => ['anonimato', 'anonymity'],
];

$TEXTO = range(1, 31);

$MULTIPLE = [
    'm1' => [
        'texto'    => 'Segun el marco del NIST tal como lo pide el taller, &iquest;en que orden van las actividades?',
        'opciones' => [
            'a' => 'Proteger, Identificar, Detectar, Recuperar, Responder',
            'b' => 'Identificar, Proteger, Detectar, Responder, Recuperar',
            'c' => 'Detectar, Responder, Identificar, Proteger, Recuperar',
            'd' => 'Identificar, Detectar, Proteger, Recuperar, Responder'
        ],
        'correcta' => 'b',
        'porque'   => 'Es una linea de tiempo: primero sabes <b>que</b> tienes, lo blindas, vigilas, reaccionas cuando pasa algo, y al final vuelves a la normalidad.'
    ],
    'm2' => [
        'texto'    => '&iquest;Por que <b>Identificar</b> va primero y no <b>Proteger</b>?',
        'opciones' => [
            'a' => 'Porque proteger es mas caro',
            'b' => 'Porque no puedes proteger algo si todavia no sabes que activos tienes ni cuales tienen valor',
            'c' => 'Porque el NIST lo ordeno alfabeticamente',
            'd' => 'Porque identificar es opcional'
        ],
        'correcta' => 'b',
        'porque'   => 'Es literal en los apuntes: &laquo;es necesario saber que informacion, sistemas o recursos tienen valor <b>antes</b> de aplicar medidas de seguridad&raquo;.'
    ],
    'm3' => [
        'texto'    => 'Un empleado borra por accidente una carpeta importante. &iquest;Que tipo de agente de amenaza es?',
        'opciones' => [
            'a' => 'No amigable, porque causo daño',
            'b' => 'Amigable, porque el daño fue accidental y viene desde dentro sin intencion maliciosa',
            'c' => 'Natural',
            'd' => 'No es un agente de amenaza'
        ],
        'correcta' => 'b',
        'porque'   => '&laquo;Amigable&raquo; no significa inofensivo: significa <b>sin intencion de hacer daño</b>. Empleados, administradores y usuarios comunes entran aqui.'
    ],
    'm4' => [
        'texto'    => '&iquest;Cual es la relacion correcta entre riesgo inherente y riesgo residual?',
        'opciones' => [
            'a' => 'El residual es el riesgo antes de los controles y el inherente el de despues',
            'b' => 'El inherente es el riesgo <b>antes</b> de aplicar controles; el residual es el que <b>queda despues</b>',
            'c' => 'Son lo mismo con distinto nombre',
            'd' => 'El residual siempre es cero si los controles son buenos'
        ],
        'correcta' => 'b',
        'porque'   => 'Y el remate que cae en el parcial: <b>el riesgo nunca llega a cero</b>, solo se reduce o se mitiga. Siempre queda residual.'
    ],
    'm5' => [
        'texto'    => 'Un correo falso lleva un adjunto que cifra los archivos del contador. En la anatomia del ataque, el <b>correo</b> es...',
        'opciones' => [
            'a' => 'El payload',
            'b' => 'El vector de ataque',
            'c' => 'La vulnerabilidad',
            'd' => 'El objetivo'
        ],
        'correcta' => 'b',
        'porque'   => 'El vector es el <b>vehiculo</b> que entrega la carga. El payload es lo que hace el daño (aqui, el cifrado de los archivos).'
    ],
    'm6' => [
        'texto'    => 'En esa misma analogia del misil, &iquest;que es el <b>payload</b>?',
        'opciones' => [
            'a' => 'El misil que vuela',
            'b' => 'La parte del ataque que causa el daño: el explosivo, el codigo que roba o destruye la informacion',
            'c' => 'El radar que lo detecta',
            'd' => 'La debilidad del blindaje'
        ],
        'correcta' => 'b',
        'porque'   => 'Vector = como llega. Payload = que hace cuando llega. Vulnerabilidad = por donde entra. Objetivo = a que le apunta.'
    ],
    'm7' => [
        'texto'    => '&iquest;Cual es la diferencia entre un <b>virus</b> y un <b>gusano</b>?',
        'opciones' => [
            'a' => 'No hay diferencia',
            'b' => 'El virus necesita copiarse dentro de archivos; el gusano se replica y se propaga <b>solo</b> por la red',
            'c' => 'El gusano solo afecta a Linux',
            'd' => 'El virus cifra archivos y el gusano los borra'
        ],
        'correcta' => 'b',
        'porque'   => 'La palabra clave del gusano es <b>automaticamente</b>: no necesita que nadie abra nada para propagarse.'
    ],
    'm8' => [
        'texto'    => 'Un programa que parece un instalador legitimo pero trae codigo malicioso dentro es un...',
        'opciones' => [
            'a' => 'Gusano',
            'b' => 'Troyano',
            'c' => 'Ransomware',
            'd' => 'Spyware'
        ],
        'correcta' => 'b',
        'porque'   => 'El nombre lo dice todo: el caballo de Troya entra porque lo dejas entrar.'
    ],
    'm9' => [
        'texto'    => '&iquest;Para que sirve el servicio de <b>autenticacion</b>?',
        'opciones' => [
            'a' => 'Para ocultar quien eres',
            'b' => 'Para demostrarle a un sistema quien eres, y evitar que otra persona se haga pasar por ti',
            'c' => 'Para cifrar los mensajes',
            'd' => 'Para asegurar que el sistema este disponible'
        ],
        'correcta' => 'b',
        'porque'   => 'El ejemplo de los apuntes: el banco necesita verificar que quien entra a la cuenta es de verdad el dueño.'
    ],
    'm10' => [
        'texto'    => '&iquest;Cual de estos es un buen ejemplo del servicio de <b>anonimato</b>?',
        'opciones' => [
            'a' => 'Un canal de denuncias donde un empleado reporta corrupcion sin revelar su identidad',
            'b' => 'Una contraseña de 20 caracteres',
            'c' => 'Un backup diario de la base de datos',
            'd' => 'Un antivirus actualizado'
        ],
        'correcta' => 'a',
        'porque'   => 'Anonimato = ocultar <b>quien</b> hizo la accion, no la accion en si. Los ejemplos del video eran el voto electronico y las transacciones tipo Bitcoin.'
    ],
    'm11' => [
        'texto'    => 'Autenticacion y anonimato parecen contrarios. &iquest;Como conviven en el voto electronico?',
        'opciones' => [
            'a' => 'No conviven, hay que elegir uno',
            'b' => 'Se autentica que tienes <b>derecho a votar</b>, pero se desliga tu identidad del voto que emitiste',
            'c' => 'El anonimato reemplaza a la autenticacion',
            'd' => 'Se autentica despues de votar'
        ],
        'correcta' => 'b',
        'porque'   => 'Son dos preguntas distintas: &laquo;&iquest;puedes votar?&raquo; y &laquo;&iquest;que votaste?&raquo;. El sistema responde la primera y olvida la segunda.'
    ],
];

iniciar($SOLUCIONES, $MULTIPLE, $TEXTO);
cabecera('2 · Riesgo, amenazas y ataques', 'notas_2 · NIST · agentes · riesgo inherente y residual');
?>

<div class="card">
  <h2>De que va esto</h2>
  <p>La segunda lectura pasa de las definiciones al <b>oficio</b>: que hace un profesional
     de ciberseguridad, quien te ataca, como se mide el riesgo y como se descompone un ataque.</p>
  <div class="nota">Otra vez, aqui las respuestas son <b>texto</b>: sin importar mayusculas
    ni tildes. Muchas se aceptan en español o en ingles.</div>
</div>


<div class="card">
  <h2>1. Las cinco actividades del marco NIST</h2>
  <p>Escribelas <b>en orden</b>. Es una linea de tiempo, no una lista suelta.</p>

  <?php linea(1, '1&ordm; — saber que activos quiero proteger', 'verbo...'); ?>
  <?php linea(2, '2&ordm; — establecer controles y medidas sobre esos activos', 'verbo...'); ?>
  <?php linea(3, '3&ordm; — monitoreo constante para descubrir ataques', 'verbo...'); ?>
  <?php linea(4, '4&ordm; — contener y mitigar el ataque para que no se propague', 'verbo...'); ?>
  <?php linea(5, '5&ordm; — restaurar los sistemas y volver a la normalidad', 'verbo...'); ?>

  <?php mc('m1'); ?>
  <?php mc('m2'); ?>

  <div class="avisoflujo">
    <b>Ojo con la version.</b> Las cinco de arriba son las del <b>CSF 1.1</b>, que es lo que
    pide tu taller. En 2024 el NIST publico el <b>CSF 2.0</b>, que añadio una <b>sexta</b>
    funcion en el centro de la rueda, dedicada a la estrategia, las politicas, los roles y
    la supervision del riesgo. Si en el parcial preguntan &laquo;cinco&raquo;, responde las cinco;
    si preguntan por la version actual, son seis.
  </div>
  <?php linea(6, 'la sexta funcion que añadio el CSF 2.0 (en ingles o en español)', 'verbo...'); ?>

  <?php enviar(); ?>
</div>


<div class="card">
  <h2>2. Al reves: dada la accion, la funcion</h2>

  <?php linea(7,  'Hacer un inventario de servidores, bases de datos y su criticidad', 'funcion...'); ?>
  <?php linea(8,  'Instalar un firewall y configurar permisos por rol', 'funcion...'); ?>
  <?php linea(9,  'Revisar los logs del SIEM y las alertas del antivirus', 'funcion...'); ?>
  <?php linea(10, 'Aislar de la red el equipo infectado para que no contagie a los demas', 'funcion...'); ?>
  <?php linea(11, 'Restaurar los datos desde el backup y volver a poner el servicio en linea', 'funcion...'); ?>

  <?php enviar(); ?>
</div>


<div class="card">
  <h2>3. Agentes de amenaza</h2>
  <p>El video divide las fuentes de amenaza en tres familias. Nombralas:</p>

  <?php linea(12, 'los de dentro que hacen daño <b>sin querer</b> (empleados, administradores, usuarios)', 'tipo...'); ?>
  <?php linea(13, 'los que atacan <b>a proposito</b> (hackers, ciberdelincuentes, creadores de malware)', 'tipo...'); ?>
  <?php linea(14, 'terremotos, incendios, inundaciones', 'tipo...'); ?>

  <table class="datos">
    <tr><th>Amigables (friendly)</th><th>por que hacen daño</th></tr>
    <tr><td>Empleados</td><td>borran o comparten archivos por accidente</td></tr>
    <tr><td>Administradores de sistemas</td><td>tienen privilegios altos: un error suyo tumba sistemas enteros</td></tr>
    <tr><td>Usuarios comunes</td><td>abren enlaces maliciosos por desconocimiento</td></tr>
  </table>
  <table class="datos">
    <tr><th>No amigables (unfriendly)</th><th>que buscan</th></tr>
    <tr><td>Hackers</td><td>acceder a sistemas sin autorizacion</td></tr>
    <tr><td>Ciberdelincuentes</td><td>robar informacion o dinero</td></tr>
    <tr><td>Creadores de malware</td><td>desarrollar el software con el que se ataca</td></tr>
  </table>

  <?php mc('m3'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>4. Riesgo inherente y riesgo residual</h2>

  <?php linea(15, 'el riesgo que existe <b>antes</b> de aplicar controles; depende de la probabilidad de la amenaza y del impacto sobre el activo', 'escribe el termino...'); ?>
  <?php linea(16, 'el riesgo que <b>queda</b> despues de aplicar los controles', 'escribe el termino...'); ?>

  <div class="nota">La frase que hay que poder soltar de memoria:
    <b>el riesgo nunca puede llegar completamente a cero; solamente puede reducirse o mitigarse.</b></div>

  <?php mc('m4'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>5. Anatomia de un ataque</h2>
  <p>Cuatro atributos principales y dos vectores extra. Es la analogia del misil.</p>

  <?php linea(17, 'el metodo o vehiculo que <b>entrega</b> la carga maliciosa (un correo, un enlace, un archivo)', 'escribe el termino...'); ?>
  <?php linea(18, 'la parte del ataque que <b>causa el daño</b>: robar, modificar o destruir informacion', 'escribe el termino...'); ?>
  <?php linea(19, 'la <b>debilidad</b> del sistema que el atacante aprovecha', 'escribe el termino...'); ?>
  <?php linea(20, 'el activo o sistema al que el atacante le <b>apunta</b>', 'escribe el termino...'); ?>

  <p>Y los dos caminos:</p>
  <?php linea(21, 'el camino por el que el atacante <b>entra</b> al sistema', 'escribe el termino...'); ?>
  <?php linea(22, 'el camino por el que <b>saca</b> la informacion del sistema', 'escribe el termino...'); ?>

  <?php mc('m5'); ?>
  <?php mc('m6'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>6. Tipos de malware y de ataque</h2>
  <p>Dada la definicion, el nombre.</p>

  <?php linea(23, 'programa malicioso que se <b>copia</b> y puede dañar o modificar archivos', 'nombre...'); ?>
  <?php linea(24, 'malware que se replica y se propaga <b>automaticamente por redes</b>', 'nombre...'); ?>
  <?php linea(25, 'programa que <b>parece legitimo</b> pero contiene codigo malicioso', 'nombre...'); ?>
  <?php linea(26, 'malware que <b>cifra o bloquea</b> la informacion y exige un pago', 'nombre...'); ?>
  <?php linea(27, 'software que <b>espia</b> y recopila la actividad del usuario sin autorizacion', 'nombre...'); ?>
  <?php linea(28, 'engaño con mensajes o sitios falsos para que la victima <b>entregue</b> su informacion', 'nombre...'); ?>
  <?php linea(29, 'ataque que <b>impide</b> que los usuarios legitimos accedan a un servicio', 'nombre o sigla...'); ?>

  <?php mc('m7'); ?>
  <?php mc('m8'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>7. Dos servicios que se contraponen</h2>

  <?php linea(30, 'el servicio que <b>demuestra quien eres</b> ante un sistema', 'servicio...'); ?>
  <?php linea(31, 'el servicio que <b>oculta quien eres</b> al realizar una accion o transaccion', 'servicio...'); ?>

  <?php mc('m9'); ?>
  <?php mc('m10'); ?>
  <?php mc('m11'); ?>

  <?php enviar('Verificar todo el cuestionario'); ?>
</div>

<?php
pie('../Fundamentos/index.php', '../Criptografia/index.php');
