<?php
/* ==========================================================================
   CiberSeguridad / Criptografia
   Fuente: notas_3.pdf (Tab 5, preguntas 1 a 9 + transposicion)
   ========================================================================== */

require_once __DIR__ . '/../motor.php';

$SOLUCIONES = [
    /* --- conceptos --- */
    1  => ['criptografia'],
    2  => ['criptoanalisis'],
    3  => ['cifrado', 'encryption', 'encriptacion'],
    4  => ['descifrado', 'decryption'],
    5  => ['texto plano', 'plaintext', 'texto claro'],
    6  => ['texto cifrado', 'ciphertext'],

    /* --- las dos operaciones fundamentales --- */
    7  => ['sustitucion', 'substitution'],
    8  => ['transposicion', 'transposition'],

    /* --- longitud de clave --- */
    9  => ['se duplica', 'duplica', 'se dobla', 'el doble'],

    /* --- Cesar --- */
    10 => ['HWDUYTLWFUMD NX KZS', 'HWDUYTLWFUMDNXKZS'],
    11 => ['XJHZWNYD'],
    12 => ['HASH'],
    13 => ['ATTACK'],

    /* --- Vigenere --- */
    14 => ['BOATBOATBOATBOATB'],
    15 => ['DFYIUCGKBDHRJGFNO'],
    16 => ['polialfabetico', 'polialfabetica', 'polyalphabetic'],

    /* --- transposicion --- */
    17 => ['LGROH'],
    18 => ['EOTNT'],
    19 => ['TPYI'],
    20 => ['SATG'],
    21 => ['LGROH EOTNT TPYI SATG', 'LGROHEOTNTTPYISATG'],

    /* --- simetrico vs asimetrico --- */
    22 => ['compartir la clave', 'el intercambio de claves', 'compartir la clave secreta',
           'intercambio de claves', 'compartir la clave de forma segura'],
    23 => ['clave publica', 'public key'],
    24 => ['clave privada', 'private key'],
    25 => ['son mas lentos', 'mas lentos', 'la velocidad', 'lentitud', 'que son mas lentos'],

    /* --- hash --- */
    26 => ['efecto avalancha', 'avalancha', 'avalanche effect'],
    27 => ['64'],
    28 => ['128'],
];

$TEXTO = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28];

$MULTIPLE = [
    'm1' => [
        'texto'    => '&iquest;Por que una clave larga es mas segura que una corta?',
        'opciones' => [
            'a' => 'Porque el algoritmo se vuelve secreto',
            'b' => 'Porque aumenta el numero de combinaciones posibles que hay que probar: <b>cada bit extra duplica</b> el trabajo del criptoanalista',
            'c' => 'Porque el cifrado se vuelve mas rapido',
            'd' => 'Porque las claves largas no se pueden copiar'
        ],
        'correcta' => 'b',
        'porque'   => 'Es crecimiento exponencial: una clave de n bits tiene 2<sup>n</sup> posibilidades. Pasar de 127 a 128 bits <b>duplica</b> el espacio de busqueda.'
    ],
    'm2' => [
        'texto'    => '&iquest;Cual es la diferencia entre criptografia y criptoanalisis?',
        'opciones' => [
            'a' => 'La criptografia crea algoritmos seguros; el criptoanalisis intenta romperlos',
            'b' => 'El criptoanalisis crea algoritmos y la criptografia los rompe',
            'c' => 'Son sinonimos',
            'd' => 'La criptografia es teorica y el criptoanalisis es la implementacion'
        ],
        'correcta' => 'a',
        'porque'   => 'Una construye, la otra ataca. Son las dos caras de la criptologia.'
    ],
    'm3' => [
        'texto'    => 'En el cifrado <b>Cesar</b>, &iquest;que le pasa a las letras?',
        'opciones' => [
            'a' => 'Se reordenan sin cambiar',
            'b' => 'Cada letra se <b>sustituye</b> por otra, desplazada un numero fijo de posiciones',
            'c' => 'Se eliminan las vocales',
            'd' => 'Se convierten a numeros'
        ],
        'correcta' => 'b',
        'porque'   => 'Cesar es <b>sustitucion</b>: A&rarr;F, B&rarr;G, C&rarr;H con desplazamiento 5. Los simbolos cambian.'
    ],
    'm4' => [
        'texto'    => 'En la <b>transposicion</b>, &iquest;que le pasa a las letras?',
        'opciones' => [
            'a' => 'Cada una se reemplaza por otra del alfabeto',
            'b' => 'No cambian: son <b>las mismas letras</b>, solo cambia el orden en que se leen',
            'c' => 'Se duplican',
            'd' => 'Se convierten a hexadecimal'
        ],
        'correcta' => 'b',
        'porque'   => 'Esa es la frase clave: en transposicion la L sigue siendo L. Solo cambia la <b>posicion</b>. Por eso el texto cifrado tiene exactamente las mismas letras que el original.'
    ],
    'm5' => [
        'texto'    => '&iquest;Por que el Vigenere se llama cifrado <b>polialfabetico</b>?',
        'opciones' => [
            'a' => 'Porque usa varios idiomas',
            'b' => 'Porque el desplazamiento <b>cambia</b> en cada letra segun la clave, en vez de ser uno solo fijo',
            'c' => 'Porque usa el alfabeto griego',
            'd' => 'Porque cifra dos veces'
        ],
        'correcta' => 'b',
        'porque'   => 'Cesar usa un unico alfabeto desplazado (mono-alfabetico). Vigenere usa uno distinto por posicion, marcado por la clave. Por eso resiste el analisis de frecuencias.'
    ],
    'm6' => [
        'texto'    => '&iquest;Cual es el problema principal de los cifrados <b>simetricos</b>?',
        'opciones' => [
            'a' => 'Que son muy lentos',
            'b' => 'Que hay que <b>compartir la clave secreta</b> de forma segura; si alguien la obtiene, puede descifrar los mensajes y hacerse pasar por los usuarios',
            'c' => 'Que solo funcionan con texto en ingles',
            'd' => 'Que necesitan dos claves distintas'
        ],
        'correcta' => 'b',
        'porque'   => 'Es la paradoja del huevo y la gallina: para intercambiar mensajes seguros necesitas ya un canal seguro por donde mandar la clave.'
    ],
    'm7' => [
        'texto'    => '&iquest;Cual es la ventaja y cual la desventaja de los cifrados <b>asimetricos</b>?',
        'opciones' => [
            'a' => 'Ventaja: son mas rapidos. Desventaja: usan una sola clave',
            'b' => 'Ventaja: resuelven el intercambio de claves usando clave publica y privada. Desventaja: son <b>mas lentos</b> que los simetricos',
            'c' => 'Ventaja: no necesitan clave. Desventaja: son inseguros',
            'd' => 'Ventaja: la clave privada se puede publicar. Desventaja: ocupan mas espacio'
        ],
        'correcta' => 'b',
        'porque'   => 'Por eso en la practica se combinan: se usa asimetrico para <b>acordar</b> una clave y simetrico para <b>cifrar</b> los datos, que es lo pesado.'
    ],
    'm8' => [
        'texto'    => 'Calculaste el hash de tu nombre en mayusculas y en minusculas y salieron <b>completamente</b> distintos. &iquest;Como se llama esa propiedad?',
        'opciones' => [
            'a' => 'Colision',
            'b' => 'Efecto avalancha',
            'c' => 'Sal (salting)',
            'd' => 'Difusion de clave'
        ],
        'correcta' => 'b',
        'porque'   => 'Un cambio minimo en la entrada produce una salida totalmente diferente. Si no fuera asi, se podria adivinar el mensaje comparando hashes parecidos.'
    ],
    'm9' => [
        'texto'    => 'Una clave de 128 bits. &iquest;Cuantas combinaciones posibles hay?',
        'opciones' => [
            'a' => '128',
            'b' => '128<sup>2</sup>',
            'c' => '2<sup>128</sup>',
            'd' => '128!'
        ],
        'correcta' => 'c',
        'porque'   => 'Cada bit es un si/no independiente: 2 &times; 2 &times; ... 128 veces = 2<sup>128</sup>. Y añadir el bit 129 lo <b>duplica</b> otra vez.'
    ],
];

iniciar($SOLUCIONES, $MULTIPLE, $TEXTO);
cabecera('3 · Criptografia', 'notas_3 (Tab 5) · Cesar, Vigenere, transposicion, simetrico/asimetrico, hash');
?>

<div class="card">
  <h2>El mapa</h2>
  <pre><code>CRIPTOLOGIA
├── Criptografia    -> construir algoritmos seguros
└── Criptoanalisis  -> romperlos

Dos operaciones fundamentales:
├── Sustitucion   -> las letras CAMBIAN   (Cesar, Vigenere)
└── Transposicion -> las letras se REORDENAN

Dos familias de cifrado:
├── Simetrico  -> una sola clave   -> problema: compartirla
└── Asimetrico -> publica+privada  -> resuelve eso, pero es mas lento</code></pre>
  <div class="nota">En esta pagina las respuestas de texto ignoran mayusculas y tildes.
    Los textos cifrados escribelos en mayusculas o minusculas, da igual.</div>
</div>


<div class="card">
  <h2>1. Vocabulario base</h2>

  <?php linea(1, 'la ciencia de <b>crear</b> algoritmos seguros para proteger la informacion', 'escribe el termino...'); ?>
  <?php linea(2, 'la ciencia de <b>romper o atacar</b> esos algoritmos', 'escribe el termino...'); ?>
  <?php linea(3, 'la operacion que transforma el mensaje original en uno ilegible', 'escribe el termino...'); ?>
  <?php linea(4, 'la operacion que devuelve el mensaje ilegible a su forma original', 'escribe el termino...'); ?>
  <?php linea(5, 'como se llama el mensaje <b>antes</b> de cifrar', 'escribe el termino...'); ?>
  <?php linea(6, 'como se llama el mensaje <b>despues</b> de cifrar', 'escribe el termino...'); ?>

  <p>Y las dos operaciones fundamentales sobre las que se construye todo:</p>
  <?php linea(7, 'la que <b>cambia</b> unos simbolos por otros', 'escribe el termino...'); ?>
  <?php linea(8, 'la que <b>solo reordena</b> los simbolos que ya estaban', 'escribe el termino...'); ?>

  <?php mc('m2'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>2. Longitud de la clave</h2>
  <p>Completa la frase de los apuntes: <em>&laquo;cada bit adicional
     <?php hueco(9, 14); ?> el trabajo necesario para que un criptoanalista rompa la clave&raquo;</em>.</p>

  <?php mc('m1'); ?>
  <?php mc('m9'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>3. Cifrado Cesar (+5)</h2>
  <p>Desplazas cada letra 5 posiciones hacia adelante en el alfabeto ingles.
     Si te pasas de la Z, vuelves a empezar por la A.</p>
  <pre><code>A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
+5:
F G H I J K L M N O P Q R S T U V W X Y Z A B C D E</code></pre>

  <p>El del taller:</p>
  <?php linea(10, 'cifra <code>CRYPTOGRAPHY IS FUN</code> con Cesar +5', 'texto cifrado...'); ?>
  <?php ayuda('C&rarr;H, R&rarr;W, Y&rarr;D... y sigue. Los espacios se respetan.'); ?>

  <p>Dos mas para practicar el mecanismo:</p>
  <?php linea(11, 'cifra <code>SECURITY</code> con Cesar +5', 'texto cifrado...'); ?>
  <?php linea(12, '<b>descifra</b> <code>MFXM</code> (Cesar +5, o sea retrocede 5)', 'texto original...'); ?>
  <?php linea(13, '<b>descifra</b> <code>FYYFHP</code>', 'texto original...'); ?>

  <?php mc('m3'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>4. Cifrado Vigenere con clave <code>BOAT</code></h2>
  <p>Cada letra de la clave dice cuanto desplazar: <code>B</code>=+1, <code>O</code>=+14,
     <code>A</code>=+0, <code>T</code>=+19. La clave se repite hasta cubrir el mensaje.</p>

  <p>Texto plano: <code>CRYPTOGRAPHYISFUN</code> (17 letras).</p>
  <?php linea(14, 'escribe la <b>clave repetida</b> debajo, letra a letra, hasta completar las 17', 'BOATBOAT...'); ?>
  <?php linea(15, 'ahora el resultado cifrado', 'texto cifrado...'); ?>
  <?php ayuda('C+B = D, R+O = F, Y+A = Y, P+T = I... el resultado empieza por <code>DFYI</code>.'); ?>

  <p>Se dice que Vigenere es un cifrado de sustitucion <?php hueco(16, 18); ?> .</p>

  <?php mc('m5'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>5. Transposicion</h2>
  <p>Se escribe <code>LET'S GO PARTY TONIGHT</code> en una matriz de <b>4 columnas</b>
     y en vez de leer por filas se lee por <b>columnas</b>:</p>

  <pre><code>L E T S
G O P A
R T Y T
O N I G
H T</code></pre>

  <?php linea(17, 'primera columna, leida hacia abajo', 'columna 1...'); ?>
  <?php linea(18, 'segunda columna', 'columna 2...'); ?>
  <?php linea(19, 'tercera columna', 'columna 3...'); ?>
  <?php linea(20, 'cuarta columna', 'columna 4...'); ?>
  <?php linea(21, 'el mensaje cifrado completo (las cuatro columnas seguidas)', 'mensaje cifrado...'); ?>

  <div class="nota">Fijate: el resultado tiene <b>exactamente las mismas 18 letras</b> que el
    original, solo desordenadas. Eso es lo que lo separa de Cesar, donde los simbolos si cambian.</div>

  <?php mc('m4'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>6. Simetrico vs. asimetrico</h2>

  <p>El problema principal de los cifrados <b>simetricos</b> es
     <?php hueco(22, 26); ?> de forma segura.</p>

  <p>Los <b>asimetricos</b> lo resuelven usando dos claves:</p>
  <?php linea(23, 'la que se puede repartir a cualquiera', 'escribe el termino...'); ?>
  <?php linea(24, 'la que jamas sale de su dueño', 'escribe el termino...'); ?>

  <p>A cambio, su desventaja principal es que <?php hueco(25, 20); ?> .</p>

  <?php mc('m6'); ?>
  <?php mc('m7'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>7. Funciones hash</h2>
  <p>En el taller sacaste el SHA-256 y el SHA-512 de tu nombre en mayusculas y en minusculas.
     El unico cambio fue la capitalizacion, y los hashes salieron <b>totalmente</b> distintos.</p>

  <?php linea(26, 'el nombre de esa propiedad', 'escribe el termino...'); ?>

  <p>Y para no dudar en el parcial, cuantos caracteres hexadecimales tiene cada salida:</p>
  <table class="datos">
    <tr><th>Funcion</th><th>bits</th><th>caracteres hex</th></tr>
    <tr><td>SHA-256</td><td>256</td><td><?php hueco(27, 6); ?></td></tr>
    <tr><td>SHA-512</td><td>512</td><td><?php hueco(28, 6); ?></td></tr>
  </table>
  <?php ayuda('Cada caracter hexadecimal representa 4 bits, asi que basta con dividir los bits entre 4.'); ?>

  <?php mc('m8'); ?>
  <?php enviar('Verificar todo el cuestionario'); ?>
</div>

<?php
pie('../Riesgos/index.php', '../Normas/index.php');
