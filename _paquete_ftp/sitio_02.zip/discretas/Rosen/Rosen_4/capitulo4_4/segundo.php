<?php
 
 
$respuesta_1 = ''; $respuesta_2 = ''; $respuesta_3 = ''; $respuesta_3_2 = ''; $respuesta_4 = ''; $respuesta_5 = ''; 
$respuesta_6 = ''; $respuesta_7 = ''; $respuesta_8 = ''; $respuesta_9 = '';  $respuesta_10 = '';
$respuesta_11 = ''; $respuesta_12 = ''; $respuesta_13 = ''; $respuesta_14 = ''; $respuesta_15 = '';
$respuesta_16 = ''; $respuesta_17 = ''; $respuesta_18 = ''; $respuesta_19 = ''; $respuesta_20 = '';
$respuesta_21 = ''; $respuesta_22 = '';  $respuesta_23 = '';  $respuesta_24 = '';
$respuesta_25 = ''; $respuesta_26 = ''; $respuesta_27 = ''; $respuesta_28 = ''; $respuesta_29 = '';
$respuesta_30 = ''; $respuesta_31 = ''; $respuesta_32 = ''; $respuesta_33 = ''; $respuesta_34 = ''; $respuesta_35 = ''; $respuesta_36 = ''; $respuesta_37 = ''; $respuesta_38 = '';
$respuesta_39 = ''; $respuesta_40 = ''; $respuesta_41 = ''; $respuesta_42 = ''; $respuesta_43 = '';
$respuesta_44 = ''; $respuesta_45 = ''; $respuesta_46 = ''; $respuesta_47 = ''; $respuesta_48 = '';
$respuesta_49 = ''; $respuesta_50 = ''; $respuesta_51 = ''; $respuesta_52 = ''; $respuesta_53 = '';
$respuesta_54 = ''; $respuesta_55 = ''; $respuesta_56 = '';
$respuesta_57 = ''; $respuesta_58 = ''; $respuesta_59 = ''; $respuesta_60 = '';
$respuesta_61 = '';$respuesta_62 = '';$respuesta_63 = '';$respuesta_64 = '';
$respuesta_65 = '';$respuesta_66 = '';$respuesta_67 = '';$respuesta_68 = '';
$respuesta_69 = '';$respuesta_70 = '';$respuesta_71 = '';$respuesta_72 = '';
$respuesta_73 = '';$respuesta_74 = '';$respuesta_75 = '';$respuesta_76 = '';
$respuesta_77 = '';$respuesta_78 = '';$respuesta_79 = '';$respuesta_80 = '';
$respuesta_81 = '';$respuesta_82 = '';$respuesta_83 = '';$respuesta_84 = '';
$respuesta_85 = '';$respuesta_86 = '';$respuesta_87 = '';$respuesta_88 = ''; $respuesta_89 = '';
$respuesta_90 = '';
$respuesta_91 = '';
$respuesta_92 = '';
$respuesta_93 = '';
$respuesta_94 = '';
$respuesta_95 = '';
$respuesta_96 = '';
$respuesta_97 = '';
$respuesta_98 = '';
$respuesta_99 = '';
$respuesta_100 = '';
$respuesta_101 = '';
$respuesta_102 = '';
$respuesta_103 = '';
$respuesta_104 = '';
$respuesta_105 = '';
$respuesta_106 = '';
$respuesta_107 = '';
$respuesta_108 = '';
$respuesta_109 = '';
$respuesta_110 = '';


 

$verificar_1 = ''; $verificar_2 = ''; $verificar_3 = '';  $verificar_3_2 = ''; $verificar_4 = ''; $verificar_5 = ''; 
$verificar_6 = ''; $verificar_7 = '';  $verificar_8 = ''; $verificar_9 = ''; $verificar_10 = ''; 
$verificar_11 = ''; $verificar_12 = ''; $verificar_13 = ''; $verificar_14 = ''; $verificar_15 = ''; 
$verificar_16 = '';  $verificar_17 = ''; $verificar_18 = ''; $verificar_19 = ''; $verificar_20 = '';  
$verificar_21 = '';  $verificar_22 = '';  $verificar_23 = '';   $verificar_24 = '';   $verificar_25 = '';  
$verificar_26 = '';  $verificar_27= ''; $verificar_28= '';  $verificar_29= '';  $verificar_30 = ''; 
$verificar_31 = ''; $verificar_32 = ''; $verificar_33 = ''; 
$verificar_34 = ''; $verificar_35 = ''; $verificar_36 = ''; $verificar_37 = ''; $verificar_38 = '';
$verificar_39 = ''; $verificar_40 = ''; $verificar_41 = ''; $verificar_42 = ''; $verificar_43 = '';
$verificar_44 = ''; $verificar_45 = ''; $verificar_46 = ''; $verificar_47 = ''; $verificar_48 = '';
$verificar_49 = ''; $verificar_50 = ''; $verificar_51 = ''; $verificar_52 = ''; $verificar_53 = '';
$verificar_54 = ''; $verificar_55 = '';
$verificar_56 = ''; $verificar_57 = ''; $verificar_58 = ''; $verificar_59 = ''; $verificar_60 = ''; 
$verificar_61 = ''; $verificar_62 = ''; $verificar_63 = ''; $verificar_64 = ''; $verificar_65 = '';
 $verificar_66 = ''; $verificar_67 = ''; $verificar_68 = ''; $verificar_69 = ''; $verificar_70 = '';
  $verificar_71 = ''; $verificar_72 = ''; $verificar_73 = ''; $verificar_74 = ''; $verificar_75 = '';
   $verificar_76 = ''; $verificar_77 = ''; $verificar_78 = ''; $verificar_79 = ''; $verificar_80 = '';
    $verificar_81 = ''; $verificar_82 = ''; $verificar_83 = ''; $verificar_84 = ''; $verificar_85 = '';
     $verificar_86 = ''; $verificar_87 = ''; $verificar_88 = '';
     $verificar_89 = '';
     $verificar_90 = '';
     $verificar_91 = '';
     $verificar_92 = '';
     $verificar_93 = '';
     $verificar_94 = '';
     $verificar_95 = '';
     $verificar_96 = '';
     $verificar_97 = '';
     $verificar_98 = '';
     $verificar_99 = '';
     $verificar_100 = '';
     $verificar_101 = '';
     $verificar_102 = '';
     $verificar_103 = '';
     $verificar_104 = '';
     $verificar_105 = '';
     $verificar_106 = '';
     $verificar_107 = '';
     $verificar_108 = '';
     $verificar_109 = '';
     $verificar_110 = '';
     

if ($_POST) {
    $respuesta_1 = isset($_POST['respuesta_1']) ? $_POST['respuesta_1'] : '';
   if ($respuesta_1 === '26') {  
       $verificar_1 = "correcto";
   } elseif ($respuesta_1 === '') {
       $verificar_1 = '';
   } else {
       $verificar_1 = "incorrecto";
   }

   // Verificar la respuesta de la segunda pregunta
   $respuesta_2 = isset($_POST['respuesta_2']) ? $_POST['respuesta_2'] : '';
   if ($respuesta_2 === '39') {  
       $verificar_2 = "correcto";
   } elseif ($respuesta_2 === '') {
       $verificar_2 = '';
   } else {
       $verificar_2 = "incorrecto";
   }

   // Verificar la respuesta de la tercera pregunta
   $respuesta_3 = isset($_POST['respuesta_3']) ? $_POST['respuesta_3'] : '';
   if ($respuesta_3 === '52') {  
       $verificar_3 = "correcto";
   } elseif ($respuesta_3 === '') {
       $verificar_3 = '';
   } else {
       $verificar_3 = "incorrecto";
   }

   // Verificar la respuesta de la cuarta pregunta
   $respuesta_4 = isset($_POST['respuesta_4']) ? $_POST['respuesta_4'] : '';
   if ($respuesta_4 === '65') {  
       $verificar_4 = "correcto";
   } elseif ($respuesta_4 === '') {
       $verificar_4 = '';
   } else {
       $verificar_4 = "incorrecto";
   }

   // Verificar la respuesta de la quinta pregunta
   $respuesta_5 = isset($_POST['respuesta_5']) ? $_POST['respuesta_5'] : '';
   if ($respuesta_5 === '78') {  
       $verificar_5 = "correcto";
   } elseif ($respuesta_5 === '') {
       $verificar_5 = '';
   } else {
       $verificar_5 = "incorrecto";
   }

   // Verificar la respuesta de la sexta pregunta
   $respuesta_6 = isset($_POST['respuesta_6']) ? $_POST['respuesta_6'] : '';
   if ($respuesta_6 === '91') {  
       $verificar_6 = "correcto";
   } elseif ($respuesta_6 === '') {
       $verificar_6 = '';
   } else {
       $verificar_6 = "incorrecto";
   }

   // Verificar la respuesta de la séptima pregunta
   $respuesta_7 = isset($_POST['respuesta_7']) ? $_POST['respuesta_7'] : '';
   if ($respuesta_7 === '104') {  
       $verificar_7 = "correcto";
   } elseif ($respuesta_7 === '') {
       $verificar_7 = '';
   } else {
       $verificar_7 = "incorrecto";
   }

   // Verificar la respuesta de la octava pregunta
   $respuesta_8 = isset($_POST['respuesta_8']) ? $_POST['respuesta_8'] : '';
   if ($respuesta_8 === '117') {  
       $verificar_8 = "correcto";
   } elseif ($respuesta_8 === '') {
       $verificar_8 = '';
   } else {
       $verificar_8 = "incorrecto";
   }

   // Verificar la respuesta de la novena pregunta
   $respuesta_9 = isset($_POST['respuesta_9']) ? $_POST['respuesta_9'] : '';
   if ($respuesta_9 === '130') {  
       $verificar_9 = "correcto";
   } elseif ($respuesta_9 === '') {
       $verificar_9 = '';
   } else {
       $verificar_9 = "incorrecto";
   }

   // Verificar la respuesta de la décima pregunta
   $respuesta_10 = isset($_POST['respuesta_10']) ? $_POST['respuesta_10'] : '';
   if ($respuesta_10 === '143') {  
       $verificar_10 = "correcto";
   } elseif ($respuesta_10 === '') {
       $verificar_10 = '';
   } else {
       $verificar_10 = "incorrecto";
   }

   // Verificar la respuesta de la undécima pregunta
   $respuesta_11 = isset($_POST['respuesta_11']) ? $_POST['respuesta_11'] : '';
   if ($respuesta_11 === '156') {  
       $verificar_11 = "correcto";
   } elseif ($respuesta_11 === '') {
       $verificar_11 = '';
   } else {
       $verificar_11 = "incorrecto";
   }


     // Verificar la respuesta de la primera pregunta
     $respuesta_12 = isset($_POST['respuesta_12']) ? $_POST['respuesta_12'] : '';
     if ($respuesta_12 === '28') {  
         $verificar_12 = "correcto";
     } elseif ($respuesta_12 === '') {
         $verificar_12 = '';
     } else {
         $verificar_12 = "incorrecto";
     }
  
     // Verificar la respuesta de la segunda pregunta
     $respuesta_13 = isset($_POST['respuesta_13']) ? $_POST['respuesta_13'] : '';
     if ($respuesta_13 === '42') { 
         $verificar_13 = "correcto";
     } elseif ($respuesta_13 === '') {
         $verificar_13 = '';
     } else {
         $verificar_13 = "incorrecto";
     }
  
     // Verificar la respuesta de la tercera pregunta
     $respuesta_14 = isset($_POST['respuesta_14']) ? $_POST['respuesta_14'] : '';
     if ($respuesta_14 === '56') {  
         $verificar_14 = "correcto";
     } elseif ($respuesta_14 === '') {
         $verificar_14 = '';
     } else {
         $verificar_14 = "incorrecto";
     }
  
     // Verificar la respuesta de la cuarta pregunta
     $respuesta_15 = isset($_POST['respuesta_15']) ? $_POST['respuesta_15'] : '';
     if ($respuesta_15 === '70') { 
         $verificar_15 = "correcto";
     } elseif ($respuesta_15 === '') {
         $verificar_15 = '';
     } else {
         $verificar_15 = "incorrecto";
     }
  
     // Verificar la respuesta de la quinta pregunta
     $respuesta_16 = isset($_POST['respuesta_16']) ? $_POST['respuesta_16'] : '';
     if ($respuesta_16 === '84') {  
         $verificar_16 = "correcto";
     } elseif ($respuesta_16 === '') {
         $verificar_16 = '';
     } else {
         $verificar_16 = "incorrecto";
     }
  
     // Verificar la respuesta de la sexta pregunta
     $respuesta_17 = isset($_POST['respuesta_17']) ? $_POST['respuesta_17'] : '';
     if ($respuesta_17 === '98') {  
         $verificar_17 = "correcto";
     } elseif ($respuesta_17 === '') {
         $verificar_17 = '';
     } else {
         $verificar_17 = "incorrecto";
     }
  
     // Verificar la respuesta de la séptima pregunta
     $respuesta_18 = isset($_POST['respuesta_18']) ? $_POST['respuesta_18'] : '';
     if ($respuesta_18 === '112') {  
         $verificar_18 = "correcto";
     } elseif ($respuesta_18 === '') {
         $verificar_18 = '';
     } else {
         $verificar_18 = "incorrecto";
     }
  
     // Verificar la respuesta de la octava pregunta
     $respuesta_19 = isset($_POST['respuesta_19']) ? $_POST['respuesta_19'] : '';
     if ($respuesta_19 === '126') {  
         $verificar_19 = "correcto";
     } elseif ($respuesta_19 === '') {
         $verificar_19 = '';
     } else {
         $verificar_19 = "incorrecto";
     }
  
     // Verificar la respuesta de la novena pregunta
     $respuesta_20 = isset($_POST['respuesta_20']) ? $_POST['respuesta_20'] : '';
     if ($respuesta_20 === '140') {  
         $verificar_20 = "correcto";
     } elseif ($respuesta_20 === '') {
         $verificar_20 = '';
     } else {
         $verificar_20 = "incorrecto";
     }
  
     // Verificar la respuesta de la décima pregunta
     $respuesta_21 = isset($_POST['respuesta_21']) ? $_POST['respuesta_21'] : '';
     if ($respuesta_21 === '154') {  
         $verificar_21 = "correcto";
     } elseif ($respuesta_21 === '') {
         $verificar_21 = '';
     } else {
         $verificar_21 = "incorrecto";
     }
  
     // Verificar la respuesta de la undécima pregunta
     $respuesta_22 = isset($_POST['respuesta_22']) ? $_POST['respuesta_22'] : '';
     if ($respuesta_22 === '168') {  
         $verificar_22 = "correcto";
     } elseif ($respuesta_22 === '') {
         $verificar_22 = '';
     } else {
         $verificar_22 = "incorrecto";
     }

     // Verificar la respuesta de la primera pregunta
   $respuesta_23 = isset($_POST['respuesta_23']) ? $_POST['respuesta_23'] : '';
   if ($respuesta_23 === '30') {  
       $verificar_23 = "correcto";
   } elseif ($respuesta_23 === '') {
       $verificar_23 = '';
   } else {
       $verificar_23 = "incorrecto";
   }

   // Verificar la respuesta de la segunda pregunta
   $respuesta_24 = isset($_POST['respuesta_24']) ? $_POST['respuesta_24'] : '';
   if ($respuesta_24 === '45') {  
       $verificar_24 = "correcto";
   } elseif ($respuesta_24 === '') {
       $verificar_24 = '';
   } else {
       $verificar_24 = "incorrecto";
   }

   // Verificar la respuesta de la tercera pregunta
   $respuesta_25 = isset($_POST['respuesta_25']) ? $_POST['respuesta_25'] : '';
   if ($respuesta_25 === '60') { 
       $verificar_25 = "correcto";
   } elseif ($respuesta_25 === '') {
       $verificar_25 = '';
   } else {
       $verificar_25 = "incorrecto";
   }

   // Verificar la respuesta de la cuarta pregunta
   $respuesta_26 = isset($_POST['respuesta_26']) ? $_POST['respuesta_26'] : '';
   if ($respuesta_26 === '75') {  
       $verificar_26 = "correcto";
   } elseif ($respuesta_26 === '') {
       $verificar_26 = '';
   } else {
       $verificar_26 = "incorrecto";
   }

   // Verificar la respuesta de la quinta pregunta
   $respuesta_27 = isset($_POST['respuesta_27']) ? $_POST['respuesta_27'] : '';
   if ($respuesta_27 === '90') {  
       $verificar_27 = "correcto";
   } elseif ($respuesta_27 === '') {
       $verificar_27 = '';
   } else {
       $verificar_27 = "incorrecto";
   }

   // Verificar la respuesta de la sexta pregunta
   $respuesta_28 = isset($_POST['respuesta_28']) ? $_POST['respuesta_28'] : '';
   if ($respuesta_28 === '105') {  
       $verificar_28 = "correcto";
   } elseif ($respuesta_28 === '') {
       $verificar_28 = '';
   } else {
       $verificar_28 = "incorrecto";
   }

   // Verificar la respuesta de la séptima pregunta
   $respuesta_29 = isset($_POST['respuesta_29']) ? $_POST['respuesta_29'] : '';
   if ($respuesta_29 === '120') {  
       $verificar_29 = "correcto";
   } elseif ($respuesta_29 === '') {
       $verificar_29 = '';
   } else {
       $verificar_29 = "incorrecto";
   }

   // Verificar la respuesta de la octava pregunta
   $respuesta_30 = isset($_POST['respuesta_30']) ? $_POST['respuesta_30'] : '';
   if ($respuesta_30 === '135') {  
       $verificar_30 = "correcto";
   } elseif ($respuesta_30 === '') {
       $verificar_30 = '';
   } else {
       $verificar_30 = "incorrecto";
   }

   // Verificar la respuesta de la novena pregunta
   $respuesta_31 = isset($_POST['respuesta_31']) ? $_POST['respuesta_31'] : '';
   if ($respuesta_31 === '150') {  
       $verificar_31 = "correcto";
   } elseif ($respuesta_31 === '') {
       $verificar_31 = '';
   } else {
       $verificar_31 = "incorrecto";
   }

   // Verificar la respuesta de la décima pregunta
   $respuesta_32 = isset($_POST['respuesta_32']) ? $_POST['respuesta_32'] : '';
   if ($respuesta_32 === '165') {  
       $verificar_32 = "correcto";
   } elseif ($respuesta_32 === '') {
       $verificar_32 = '';
   } else {
       $verificar_32 = "incorrecto";
   }

   // Verificar la respuesta de la undécima pregunta
   $respuesta_33 = isset($_POST['respuesta_33']) ? $_POST['respuesta_33'] : '';
   if ($respuesta_33 === '180') {  
       $verificar_33 = "correcto";
   } elseif ($respuesta_33 === '') {
       $verificar_33 = '';
   } else {
       $verificar_33 = "incorrecto";
   }

 $respuesta_34 = isset($_POST['respuesta_34']) ? $_POST['respuesta_34'] : '';
if ($respuesta_34 === '32') { 
    $verificar_34 = "correcto";
} elseif ($respuesta_34 === '') {
    $verificar_34 = '';
} else {
    $verificar_34 = "incorrecto";
}

 $respuesta_35 = isset($_POST['respuesta_35']) ? $_POST['respuesta_35'] : '';
if ($respuesta_35 === '48') { 
    $verificar_35 = "correcto";
} elseif ($respuesta_35 === '') {
    $verificar_35 = '';
} else {
    $verificar_35 = "incorrecto";
}

 $respuesta_36 = isset($_POST['respuesta_36']) ? $_POST['respuesta_36'] : '';
if ($respuesta_36 === '64') { 
    $verificar_36 = "correcto";
} elseif ($respuesta_36 === '') {
    $verificar_36 = '';
} else {
    $verificar_36 = "incorrecto";
}

 $respuesta_37 = isset($_POST['respuesta_37']) ? $_POST['respuesta_37'] : '';
if ($respuesta_37 === '80') { 
    $verificar_37 = "correcto";
} elseif ($respuesta_37 === '') {
    $verificar_37 = '';
} else {
    $verificar_37 = "incorrecto";
}

 $respuesta_38 = isset($_POST['respuesta_38']) ? $_POST['respuesta_38'] : '';
if ($respuesta_38 === '96') { 
    $verificar_38 = "correcto";
} elseif ($respuesta_38 === '') {
    $verificar_38 = '';
} else {
    $verificar_38 = "incorrecto";
}

 $respuesta_39 = isset($_POST['respuesta_39']) ? $_POST['respuesta_39'] : '';
if ($respuesta_39 === '112') { 
    $verificar_39 = "correcto";
} elseif ($respuesta_39 === '') {
    $verificar_39 = '';
} else {
    $verificar_39 = "incorrecto";
}

 $respuesta_40 = isset($_POST['respuesta_40']) ? $_POST['respuesta_40'] : '';
if ($respuesta_40 === '128') { 
    $verificar_40 = "correcto";
} elseif ($respuesta_40 === '') {
    $verificar_40 = '';
} else {
    $verificar_40 = "incorrecto";
}

 $respuesta_41 = isset($_POST['respuesta_41']) ? $_POST['respuesta_41'] : '';
if ($respuesta_41 === '144') { 
    $verificar_41 = "correcto";
} elseif ($respuesta_41 === '') {
    $verificar_41 = '';
} else {
    $verificar_41 = "incorrecto";
}

 $respuesta_42 = isset($_POST['respuesta_42']) ? $_POST['respuesta_42'] : '';
if ($respuesta_42 === '160') { 
    $verificar_42 = "correcto";
} elseif ($respuesta_42 === '') {
    $verificar_42 = '';
} else {
    $verificar_42 = "incorrecto";
}

 $respuesta_43 = isset($_POST['respuesta_43']) ? $_POST['respuesta_43'] : '';
if ($respuesta_43 === '176') { 
    $verificar_43 = "correcto";
} elseif ($respuesta_43 === '') {
    $verificar_43 = '';
} else {
    $verificar_43 = "incorrecto";
}

 $respuesta_44 = isset($_POST['respuesta_44']) ? $_POST['respuesta_44'] : '';
if ($respuesta_44 === '192') { 
    $verificar_44 = "correcto";
} elseif ($respuesta_44 === '') {
    $verificar_44 = '';
} else {
    $verificar_44 = "incorrecto";
}

 $respuesta_45 = isset($_POST['respuesta_45']) ? $_POST['respuesta_45'] : '';
if ($respuesta_45 === '34') { 
    $verificar_45 = "correcto";
} elseif ($respuesta_45 === '') {
    $verificar_45 = '';
} else {
    $verificar_45 = "incorrecto";
}

 $respuesta_46 = isset($_POST['respuesta_46']) ? $_POST['respuesta_46'] : '';
if ($respuesta_46 === '51') { 
    $verificar_46 = "correcto";
} elseif ($respuesta_46 === '') {
    $verificar_46 = '';
} else {
    $verificar_46 = "incorrecto";
}

 $respuesta_47 = isset($_POST['respuesta_47']) ? $_POST['respuesta_47'] : '';
if ($respuesta_47 === '68') { 
    $verificar_47 = "correcto";
} elseif ($respuesta_47 === '') {
    $verificar_47 = '';
} else {
    $verificar_47 = "incorrecto";
}

 $respuesta_48 = isset($_POST['respuesta_48']) ? $_POST['respuesta_48'] : '';
if ($respuesta_48 === '85') { 
    $verificar_48 = "correcto";
} elseif ($respuesta_48 === '') {
    $verificar_48 = '';
} else {
    $verificar_48 = "incorrecto";
}

 $respuesta_49 = isset($_POST['respuesta_49']) ? $_POST['respuesta_49'] : '';
if ($respuesta_49 === '102') { 
    $verificar_49 = "correcto";
} elseif ($respuesta_49 === '') {
    $verificar_49 = '';
} else {
    $verificar_49 = "incorrecto";
}

 $respuesta_50 = isset($_POST['respuesta_50']) ? $_POST['respuesta_50'] : '';
if ($respuesta_50 === '119') { 
    $verificar_50 = "correcto";
} elseif ($respuesta_50 === '') {
    $verificar_50 = '';
} else {
    $verificar_50 = "incorrecto";
}

 $respuesta_51 = isset($_POST['respuesta_51']) ? $_POST['respuesta_51'] : '';
if ($respuesta_51 === '136') { 
    $verificar_51 = "correcto";
} elseif ($respuesta_51 === '') {
    $verificar_51 = '';
} else {
    $verificar_51 = "incorrecto";
}

 $respuesta_52 = isset($_POST['respuesta_52']) ? $_POST['respuesta_52'] : '';
if ($respuesta_52 === '153') { 
    $verificar_52 = "correcto";
} elseif ($respuesta_52 === '') {
    $verificar_52 = '';
} else {
    $verificar_52 = "incorrecto";
}

 $respuesta_53 = isset($_POST['respuesta_53']) ? $_POST['respuesta_53'] : '';
if ($respuesta_53 === '170') { 
    $verificar_53 = "correcto";
} elseif ($respuesta_53 === '') {
    $verificar_53 = '';
} else {
    $verificar_53 = "incorrecto";
}

 $respuesta_54 = isset($_POST['respuesta_54']) ? $_POST['respuesta_54'] : '';
if ($respuesta_54 === '187') { 
    $verificar_54 = "correcto";
} elseif ($respuesta_54 === '') {
    $verificar_54 = '';
} else {
    $verificar_54 = "incorrecto";
}

 $respuesta_55 = isset($_POST['respuesta_55']) ? $_POST['respuesta_55'] : '';
if ($respuesta_55 === '204') { 
    $verificar_55 = "correcto";
} elseif ($respuesta_55 === '') {
    $verificar_55 = '';
} else {
    $verificar_55 = "incorrecto";
}


 $respuesta_56 = isset($_POST['respuesta_56']) ? $_POST['respuesta_56'] : '';
if ($respuesta_56 === '36') { 
    $verificar_56 = "correcto";
} elseif ($respuesta_56 === '') {
    $verificar_56 = '';
} else {
    $verificar_56 = "incorrecto";
}

 $respuesta_57 = isset($_POST['respuesta_57']) ? $_POST['respuesta_57'] : '';
if ($respuesta_57 === '54') { 
    $verificar_57 = "correcto";
} elseif ($respuesta_57 === '') {
    $verificar_57 = '';
} else {
    $verificar_57 = "incorrecto";
}

 $respuesta_58 = isset($_POST['respuesta_58']) ? $_POST['respuesta_58'] : '';
if ($respuesta_58 === '72') { 
    $verificar_58 = "correcto";
} elseif ($respuesta_58 === '') {
    $verificar_58 = '';
} else {
    $verificar_58 = "incorrecto";
}

 $respuesta_59 = isset($_POST['respuesta_59']) ? $_POST['respuesta_59'] : '';
if ($respuesta_59 === '90') { 
    $verificar_59 = "correcto";
} elseif ($respuesta_59 === '') {
    $verificar_59 = '';
} else {
    $verificar_59 = "incorrecto";
}

 $respuesta_60 = isset($_POST['respuesta_60']) ? $_POST['respuesta_60'] : '';
if ($respuesta_60 === '108') { 
    $verificar_60 = "correcto";
} elseif ($respuesta_60 === '') {
    $verificar_60 = '';
} else {
    $verificar_60 = "incorrecto";
}

 $respuesta_61 = isset($_POST['respuesta_61']) ? $_POST['respuesta_61'] : '';
if ($respuesta_61 === '126') { 
    $verificar_61 = "correcto";
} elseif ($respuesta_61 === '') {
    $verificar_61 = '';
} else {
    $verificar_61 = "incorrecto";
}

 $respuesta_62 = isset($_POST['respuesta_62']) ? $_POST['respuesta_62'] : '';
if ($respuesta_62 === '144') { 
    $verificar_62 = "correcto";
} elseif ($respuesta_62 === '') {
    $verificar_62 = '';
} else {
    $verificar_62 = "incorrecto";
}

 $respuesta_63 = isset($_POST['respuesta_63']) ? $_POST['respuesta_63'] : '';
if ($respuesta_63 === '162') { 
    $verificar_63 = "correcto";
} elseif ($respuesta_63 === '') {
    $verificar_63 = '';
} else {
    $verificar_63 = "incorrecto";
}

 $respuesta_64 = isset($_POST['respuesta_64']) ? $_POST['respuesta_64'] : '';
if ($respuesta_64 === '180') { 
    $verificar_64 = "correcto";
} elseif ($respuesta_64 === '') {
    $verificar_64 = '';
} else {
    $verificar_64 = "incorrecto";
}

 $respuesta_65 = isset($_POST['respuesta_65']) ? $_POST['respuesta_65'] : '';
if ($respuesta_65 === '198') { 
    $verificar_65 = "correcto";
} elseif ($respuesta_65 === '') {
    $verificar_65 = '';
} else {
    $verificar_65 = "incorrecto";
}

 $respuesta_66 = isset($_POST['respuesta_66']) ? $_POST['respuesta_66'] : '';
if ($respuesta_66 === '216') { 
    $verificar_66 = "correcto";
} elseif ($respuesta_66 === '') {
    $verificar_66 = '';
} else {
    $verificar_66 = "incorrecto";
}

 $respuesta_67 = isset($_POST['respuesta_67']) ? $_POST['respuesta_67'] : '';
if ($respuesta_67 === '38') { 
    $verificar_67 = "correcto";
} elseif ($respuesta_67 === '') {
    $verificar_67 = '';
} else {
    $verificar_67 = "incorrecto";
}

 $respuesta_68 = isset($_POST['respuesta_68']) ? $_POST['respuesta_68'] : '';
if ($respuesta_68 === '57') { 
    $verificar_68 = "correcto";
} elseif ($respuesta_68 === '') {
    $verificar_68 = '';
} else {
    $verificar_68 = "incorrecto";
}

 $respuesta_69 = isset($_POST['respuesta_69']) ? $_POST['respuesta_69'] : '';
if ($respuesta_69 === '76') { 
    $verificar_69 = "correcto";
} elseif ($respuesta_69 === '') {
    $verificar_69 = '';
} else {
    $verificar_69 = "incorrecto";
}

 $respuesta_70 = isset($_POST['respuesta_70']) ? $_POST['respuesta_70'] : '';
if ($respuesta_70 === '95') { 
    $verificar_70 = "correcto";
} elseif ($respuesta_70 === '') {
    $verificar_70 = '';
} else {
    $verificar_70 = "incorrecto";
}

 $respuesta_71 = isset($_POST['respuesta_71']) ? $_POST['respuesta_71'] : '';
if ($respuesta_71 === '114') { 
    $verificar_71 = "correcto";
} elseif ($respuesta_71 === '') {
    $verificar_71 = '';
} else {
    $verificar_71 = "incorrecto";
}

 $respuesta_72 = isset($_POST['respuesta_72']) ? $_POST['respuesta_72'] : '';
if ($respuesta_72 === '133') { 
    $verificar_72 = "correcto";
} elseif ($respuesta_72 === '') {
    $verificar_72 = '';
} else {
    $verificar_72 = "incorrecto";
}

 $respuesta_73 = isset($_POST['respuesta_73']) ? $_POST['respuesta_73'] : '';
if ($respuesta_73 === '152') { 
    $verificar_73 = "correcto";
} elseif ($respuesta_73 === '') {
    $verificar_73 = '';
} else {
    $verificar_73 = "incorrecto";
}

 $respuesta_74 = isset($_POST['respuesta_74']) ? $_POST['respuesta_74'] : '';
if ($respuesta_74 === '171') { 
    $verificar_74 = "correcto";
} elseif ($respuesta_74 === '') {
    $verificar_74 = '';
} else {
    $verificar_74 = "incorrecto";
}

 $respuesta_75 = isset($_POST['respuesta_75']) ? $_POST['respuesta_75'] : '';
if ($respuesta_75 === '190') { 
    $verificar_75 = "correcto";
} elseif ($respuesta_75 === '') {
    $verificar_75 = '';
} else {
    $verificar_75 = "incorrecto";
}

 $respuesta_76 = isset($_POST['respuesta_76']) ? $_POST['respuesta_76'] : '';
if ($respuesta_76 === '209') { 
    $verificar_76 = "correcto";
} elseif ($respuesta_76 === '') {
    $verificar_76 = '';
} else {
    $verificar_76 = "incorrecto";
}

 $respuesta_77 = isset($_POST['respuesta_77']) ? $_POST['respuesta_77'] : '';
if ($respuesta_77 === '228') { 
    $verificar_77 = "correcto";
} elseif ($respuesta_77 === '') {
    $verificar_77 = '';
} else {
    $verificar_77 = "incorrecto";
}

 $respuesta_78 = isset($_POST['respuesta_78']) ? $_POST['respuesta_78'] : '';
if ($respuesta_78 === '40') { 
    $verificar_78 = "correcto";
} elseif ($respuesta_78 === '') {
    $verificar_78 = '';
} else {
    $verificar_78 = "incorrecto";
}

 $respuesta_79 = isset($_POST['respuesta_79']) ? $_POST['respuesta_79'] : '';
if ($respuesta_79 === '60') { 
    $verificar_79 = "correcto";
} elseif ($respuesta_79 === '') {
    $verificar_79 = '';
} else {
    $verificar_79 = "incorrecto";
}

 $respuesta_80 = isset($_POST['respuesta_80']) ? $_POST['respuesta_80'] : '';
if ($respuesta_80 === '80') { 
    $verificar_80 = "correcto";
} elseif ($respuesta_80 === '') {
    $verificar_80 = '';
} else {
    $verificar_80 = "incorrecto";
}

 $respuesta_81 = isset($_POST['respuesta_81']) ? $_POST['respuesta_81'] : '';
if ($respuesta_81 === '100') { 
    $verificar_81 = "correcto";
} elseif ($respuesta_81 === '') {
    $verificar_81 = '';
} else {
    $verificar_81 = "incorrecto";
}

 $respuesta_82 = isset($_POST['respuesta_82']) ? $_POST['respuesta_82'] : '';
if ($respuesta_82 === '120') { 
    $verificar_82 = "correcto";
} elseif ($respuesta_82 === '') {
    $verificar_82 = '';
} else {
    $verificar_82 = "incorrecto";
}

 $respuesta_83 = isset($_POST['respuesta_83']) ? $_POST['respuesta_83'] : '';
if ($respuesta_83 === '140') { 
    $verificar_83 = "correcto";
} elseif ($respuesta_83 === '') {
    $verificar_83 = '';
} else {
    $verificar_83 = "incorrecto";
}

 $respuesta_84 = isset($_POST['respuesta_84']) ? $_POST['respuesta_84'] : '';
if ($respuesta_84 === '160') { 
    $verificar_84 = "correcto";
} elseif ($respuesta_84 === '') {
    $verificar_84 = '';
} else {
    $verificar_84 = "incorrecto";
}

 $respuesta_85 = isset($_POST['respuesta_85']) ? $_POST['respuesta_85'] : '';
if ($respuesta_85 === '180') { 
    $verificar_85 = "correcto";
} elseif ($respuesta_85 === '') {
    $verificar_85 = '';
} else {
    $verificar_85 = "incorrecto";
}

 $respuesta_86 = isset($_POST['respuesta_86']) ? $_POST['respuesta_86'] : '';
if ($respuesta_86 === '200') { 
    $verificar_86 = "correcto";
} elseif ($respuesta_86 === '') {
    $verificar_86 = '';
} else {
    $verificar_86 = "incorrecto";
}

 $respuesta_87 = isset($_POST['respuesta_87']) ? $_POST['respuesta_87'] : '';
if ($respuesta_87 === '220') { 
    $verificar_87 = "correcto";
} elseif ($respuesta_87 === '') {
    $verificar_87 = '';
} else {
    $verificar_87 = "incorrecto";
}

 $respuesta_88 = isset($_POST['respuesta_88']) ? $_POST['respuesta_88'] : '';
if ($respuesta_88 === '240') { 
    $verificar_88 = "correcto";
} elseif ($respuesta_88 === '') {
    $verificar_88 = '';
} else {
    $verificar_88 = "incorrecto";
}

 $respuesta_89 = isset($_POST['respuesta_89']) ? $_POST['respuesta_89'] : '';
if ($respuesta_89 === '42') { 
    $verificar_89 = "correcto";
} elseif ($respuesta_89 === '') {
    $verificar_89 = '';
} else {
    $verificar_89 = "incorrecto";
}

 $respuesta_90 = isset($_POST['respuesta_90']) ? $_POST['respuesta_90'] : '';
if ($respuesta_90 === '63') { 
    $verificar_90 = "correcto";
} elseif ($respuesta_90 === '') {
    $verificar_90 = '';
} else {
    $verificar_90 = "incorrecto";
}

 $respuesta_91 = isset($_POST['respuesta_91']) ? $_POST['respuesta_91'] : '';
if ($respuesta_91 === '84') { 
    $verificar_91 = "correcto";
} elseif ($respuesta_91 === '') {
    $verificar_91 = '';
} else {
    $verificar_91 = "incorrecto";
}

 $respuesta_92 = isset($_POST['respuesta_92']) ? $_POST['respuesta_92'] : '';
if ($respuesta_92 === '105') { 
    $verificar_92 = "correcto";
} elseif ($respuesta_92 === '') {
    $verificar_92 = '';
} else {
    $verificar_92 = "incorrecto";
}

 $respuesta_93 = isset($_POST['respuesta_93']) ? $_POST['respuesta_93'] : '';
if ($respuesta_93 === '126') { 
    $verificar_93 = "correcto";
} elseif ($respuesta_93 === '') {
    $verificar_93 = '';
} else {
    $verificar_93 = "incorrecto";
}

 $respuesta_94 = isset($_POST['respuesta_94']) ? $_POST['respuesta_94'] : '';
if ($respuesta_94 === '147') { 
    $verificar_94 = "correcto";
} elseif ($respuesta_94 === '') {
    $verificar_94 = '';
} else {
    $verificar_94 = "incorrecto";
}

 $respuesta_95 = isset($_POST['respuesta_95']) ? $_POST['respuesta_95'] : '';
if ($respuesta_95 === '168') { 
    $verificar_95 = "correcto";
} elseif ($respuesta_95 === '') {
    $verificar_95 = '';
} else {
    $verificar_95 = "incorrecto";
}

 $respuesta_96 = isset($_POST['respuesta_96']) ? $_POST['respuesta_96'] : '';
if ($respuesta_96 === '189') { 
    $verificar_96 = "correcto";
} elseif ($respuesta_96 === '') {
    $verificar_96 = '';
} else {
    $verificar_96 = "incorrecto";
}

 $respuesta_97 = isset($_POST['respuesta_97']) ? $_POST['respuesta_97'] : '';
if ($respuesta_97 === '210') { 
    $verificar_97 = "correcto";
} elseif ($respuesta_97 === '') {
    $verificar_97 = '';
} else {
    $verificar_97 = "incorrecto";
}

 $respuesta_98 = isset($_POST['respuesta_98']) ? $_POST['respuesta_98'] : '';
if ($respuesta_98 === '231') { 
    $verificar_98 = "correcto";
} elseif ($respuesta_98 === '') {
    $verificar_98 = '';
} else {
    $verificar_98 = "incorrecto";
}

 $respuesta_99 = isset($_POST['respuesta_99']) ? $_POST['respuesta_99'] : '';
if ($respuesta_99 === '252') { 
    $verificar_99 = "correcto";
} elseif ($respuesta_99 === '') {
    $verificar_99 = '';
} else {
    $verificar_99 = "incorrecto";
}


 $respuesta_100 = isset($_POST['respuesta_100']) ? $_POST['respuesta_100'] : '';
if ($respuesta_100 === '44') { 
    $verificar_100 = "correcto";
} elseif ($respuesta_100 === '') {
    $verificar_100 = '';
} else {
    $verificar_100 = "incorrecto";
}

 $respuesta_101 = isset($_POST['respuesta_101']) ? $_POST['respuesta_101'] : '';
if ($respuesta_101 === '66') { 
    $verificar_101 = "correcto";
} elseif ($respuesta_101 === '') {
    $verificar_101 = '';
} else {
    $verificar_101 = "incorrecto";
}

 $respuesta_102 = isset($_POST['respuesta_102']) ? $_POST['respuesta_102'] : '';
if ($respuesta_102 === '88') { 
    $verificar_102 = "correcto";
} elseif ($respuesta_102 === '') {
    $verificar_102 = '';
} else {
    $verificar_102 = "incorrecto";
}

 $respuesta_103 = isset($_POST['respuesta_103']) ? $_POST['respuesta_103'] : '';
if ($respuesta_103 === '110') { 
    $verificar_103 = "correcto";
} elseif ($respuesta_103 === '') {
    $verificar_103 = '';
} else {
    $verificar_103 = "incorrecto";
}

 $respuesta_104 = isset($_POST['respuesta_104']) ? $_POST['respuesta_104'] : '';
if ($respuesta_104 === '132') { 
    $verificar_104 = "correcto";
} elseif ($respuesta_104 === '') {
    $verificar_104 = '';
} else {
    $verificar_104 = "incorrecto";
}

 $respuesta_105 = isset($_POST['respuesta_105']) ? $_POST['respuesta_105'] : '';
if ($respuesta_105 === '154') { 
    $verificar_105 = "correcto";
} elseif ($respuesta_105 === '') {
    $verificar_105 = '';
} else {
    $verificar_105 = "incorrecto";
}

 $respuesta_106 = isset($_POST['respuesta_106']) ? $_POST['respuesta_106'] : '';
if ($respuesta_106 === '176') { 
    $verificar_106 = "correcto";
} elseif ($respuesta_106 === '') {
    $verificar_106 = '';
} else {
    $verificar_106 = "incorrecto";
}

 $respuesta_107 = isset($_POST['respuesta_107']) ? $_POST['respuesta_107'] : '';
if ($respuesta_107 === '198') { 
    $verificar_107 = "correcto";
} elseif ($respuesta_107 === '') {
    $verificar_107 = '';
} else {
    $verificar_107 = "incorrecto";
}

 $respuesta_108 = isset($_POST['respuesta_108']) ? $_POST['respuesta_108'] : '';
if ($respuesta_108 === '220') { 
    $verificar_108 = "correcto";
} elseif ($respuesta_108 === '') {
    $verificar_108 = '';
} else {
    $verificar_108 = "incorrecto";
}

 $respuesta_109 = isset($_POST['respuesta_109']) ? $_POST['respuesta_109'] : '';
if ($respuesta_109 === '242') { 
    $verificar_109 = "correcto";
} elseif ($respuesta_109 === '') {
    $verificar_109 = '';
} else {
    $verificar_109 = "incorrecto";
}

 $respuesta_110 = isset($_POST['respuesta_110']) ? $_POST['respuesta_110'] : '';
if ($respuesta_110 === '264') { 
    $verificar_110 = "correcto";
} elseif ($respuesta_110 === '') {
    $verificar_110 = '';
} else {
    $verificar_110 = "incorrecto";
}


}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Preguntas sobre simplificación de expresiones matemáticas</title>
    <link rel="stylesheet" href="../../../../css/bootstrap.min.css">
    <link rel="stylesheet" href="../style.css">
    <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>

<style>
    .imagen {
        max-width: 100%;
        height: auto;
    }
    .seccion {
    width: 50%; /* El 50% del ancho de la página menos el margen izquierdo */
    padding: 20px; /* importante este padding*/
    box-sizing: border-box;
    height: 550vh;
    }
</style>
 
<script>
function handleSubmit(event) {
    event.preventDefault();

    const formData = new FormData(event.target);

    fetch(event.target.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(html => {
        document.body.innerHTML = html;

        // Asegúrate de que MathJax procese el nuevo contenido
        if (window.MathJax) {
            MathJax.typeset();
        }
        actualizarFormula();
        actualizarFormula2();
        actualizarFormula3();
        actualizarFormula4();
        actualizarFormula5();
        actualizarFormula6();
        actualizarFormula7();
        actualizarFormula8();
        actualizarFormula9();
        actualizarFormula10();
        actualizarFormula11();
        actualizarFormula12();
      
    })
    .catch(error => {
        console.error('Error al enviar el formulario:', error);
    });
}

function actualizarFormula() {
    // Obtener los valores de los inputs
   
    var f = document.getElementById('respuesta_11').value || "";
 


    // Construir la fórmula dinámica
    var formula = ` \\  ${f} \\, `;

    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}
 

function actualizarFormula2() {
    // Obtener los valores de los inputs
   
    var f = document.getElementById('respuesta_13').value || "";
  
    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;

    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula2').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}



function actualizarFormula3() {
    // Obtener los valores de los inputs
   
    var f = document.getElementById('respuesta_27').value || "";
 


    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;

    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula3').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}

function actualizarFormula4() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_29').value || "";
   

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula4').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}


function actualizarFormula5() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_30').value || "";
  

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula5').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}



function actualizarFormula6() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_6').value || "";
  

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula6').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}


function actualizarFormula7() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_7').value || "";
  

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula7').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}

function actualizarFormula8() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_8').value || "";
  

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula8').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}


function actualizarFormula9() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_9').value || "";
  

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula9').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}



function actualizarFormula10() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_10').value || "";
  

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula10').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}


function actualizarFormula11() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_11').value || "";
  

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula11').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}


function actualizarFormula12() {
    // Obtener los valores de los inputs
    var f = document.getElementById('respuesta_12').value || "";
  

    // Construir la fórmula dinámica
    var formula = ` \\ ${f}  \\, `;
    // Actualizar el contenido de la fórmula en el DOM
    document.getElementById('formula12').innerHTML = `$$ ${formula} $$`;

    // Re-renderizar MathJax para mostrar los cambios
    if (window.MathJax) {
        MathJax.typeset();
    }
}

function mostrarMensaje() {
    document.getElementById("mensaje").style.display = 'block';
    // Asegúrate de que MathJax procese el nuevo contenido
    MathJax.typeset([document.getElementById("mensaje")]);
}

function ocultarMensaje() {
    document.getElementById("mensaje").style.display = 'none';
}


function mostrarMensaje2() {
    document.getElementById("mensaje2").style.display = 'block';
    // Asegúrate de que MathJax procese el nuevo contenido
    MathJax.typeset([document.getElementById("mensaje")]);
}

function ocultarMensaje2() {
    document.getElementById("mensaje2").style.display = 'none';
}



function mostrarMensaje3() {
    document.getElementById("mensaje3").style.display = 'block';
    // Asegúrate de que MathJax procese el nuevo contenido
    MathJax.typeset([document.getElementById("mensaje3")]);
}

function ocultarMensaje3() {
    document.getElementById("mensaje3").style.display = 'none';
}

function mostrarMensaje4() {
    document.getElementById("mensaje4").style.display = 'block';
    // Asegúrate de que MathJax procese el nuevo contenido
    MathJax.typeset([document.getElementById("mensaje4")]);
}

function ocultarMensaje4() {
    document.getElementById("mensaje4").style.display = 'none';
}




</script>
    
</head>
<div class="seccion izquierda">
    <form action="./segundo.php" method="POST" onsubmit="handleSubmit(event)" autocomplete="off">
    <h2>4.4.5 Teorema Pequeño de Fermat</h2>
    <p>El matemático francés Pierre de Fermat, uno de los principales matemáticos de la primera mitad del siglo XVII, 
    hizo muchos descubrimientos importantes en la teoría de números. Uno de los más útiles de estos establece que \( p \) 
    divide \( a^{p-1} - 1 \) siempre que \( p \) sea primo y \( a \) sea un número entero que no sea divisible por \( p \).</p>

    <p>Fermat anunció este resultado en una carta a uno de sus corresponsales. Sin embargo, no incluyó 
    una prueba en la carta, afirmando que temía que la prueba fuera demasiado larga. Aunque Fermat nunca 
    publicó una prueba de este hecho, no cabe duda de que sabía cómo probarlo, a diferencia del resultado 
    conocido como el último teorema de Fermat. La primera prueba publicada se atribuye a Leonhard Euler.</p>

    <h3>Teorema 3: Teorema Pequeño de Fermat</h3>
    <p>Si \( p \) es primo y \( a \) es un número entero no divisible por \( p \), entonces:</p>
    <p>\[
    a^{p-1} \equiv 1 \pmod{p}
    \]</p>
    <p>Además, para todo número entero \( a \), se cumple:</p>
    <p>\[
    a^p \equiv a \pmod{p}
    \]</p>

    <p><strong>Observación:</strong> El teorema pequeño de Fermat nos dice que si \( a \in \mathbb{Z}_p \), 
    entonces \( a^{p-1} = 1 \) en \( \mathbb{Z}_p \).</p>

    <p>La prueba del Teorema 3 se esboza en el Ejercicio 19.</p>

    <p>El teorema pequeño de Fermat es extremadamente útil para calcular los restos módulo \( p \) de grandes 
    potencias de enteros, como ilustra el siguiente ejemplo.</p>




    <h3>Ejemplo 9: Calcular \( 7^{222} \mod 11 \)</h3>
    <p>Solución: Podemos usar el teorema pequeño de Fermat para evaluar \( 7^{222} \mod 11 \) en lugar de 
    usar el algoritmo rápido de exponenciación modular.</p>
    
    <p>Por el teorema pequeño de Fermat, sabemos que:</p>
    <p>\[
    7^{10} \equiv 1 \pmod{11}
    \]</p>
    <p>Por lo tanto, \( (7^{10})^k \equiv 1 \pmod{11} \) para todo entero positivo \( k \). Para aprovechar esta 
    congruencia, dividimos el exponente 222 entre 10:</p>
    <p>\[
    222 = 22 \cdot 10 + 2
    \]</p>
    <p>Entonces:</p>
    <p>\[
    7^{222} = 7^{22 \cdot 10 + 2} = (7^{10})^{22} \cdot 7^2 \equiv 1^{22} \cdot 49 \equiv 49 \pmod{11}
    \]</p>
    <p>Como \( 49 \equiv 5 \pmod{11} \), concluimos que:</p>
    <p>\[
    7^{222} \mod 11 = 5
    \]</p>

    <p>Este ejemplo ilustra cómo usar el teorema pequeño de Fermat para calcular \( a^n \mod p \), donde 
    \( p \) es primo y \( p \nmid a \).</p>

    <p>Primero, usamos el algoritmo de la división para encontrar el cociente \( q \) y el residuo \( r \) 
    cuando \( n \) se divide por \( p - 1 \), es decir:</p>
    <p>\[
    n = q(p - 1) + r \quad \text{con} \quad 0 \leq r < p - 1
    \]</p>
    <p>Entonces:</p>
    <p>\[
    a^n = a^{q(p - 1) + r} = (a^{p - 1})^q \cdot a^r \equiv 1^q \cdot a^r \equiv a^r \pmod{p}
    \]</p>
    <p>Por lo tanto, para encontrar \( a^n \mod p \), solo necesitamos calcular \( a^r \mod p \). Aprovecharemos 
    esta simplificación muchas veces en nuestro estudio de la teoría de números.</p>
    





    <h2>4.4.6 Pseudoprimos</h2>

    <p>En la Sección 4.2 mostramos que un número entero \( n \) es primo cuando no es divisible por ningún primo 
    \( p \) tal que \( p \leq \sqrt{n} \). Desafortunadamente, usar este criterio para mostrar que un número dado 
    es primo resulta ineficiente. Requiere encontrar todos los primos que no exceden \( \sqrt{n} \) y realizar 
    divisiones de prueba con cada uno para verificar si divide a \( n \).</p>

    <p>¿Existen métodos más eficientes para determinar si un número entero es primo? Según algunas fuentes, los 
    antiguos matemáticos chinos creían que \( n \) era un primo impar si, y solo si:</p>

    <p>\[ 2^{n-1} \equiv 1 \pmod{n} \]</p>

    <p>Si esto fuera cierto, sería una prueba de primalidad eficiente. ¿Por qué creían que esta congruencia podía 
    usarse para determinar si un entero \( n > 2 \) es primo? Primero, observaron que la congruencia se cumple 
    siempre que \( n \) sea un primo impar. Por ejemplo, 5 es primo y:</p>

    <p>\[ 2^{5-1} = 2^4 = 16 \equiv 1 \pmod{5} \]</p>

    <p>Por el pequeño teorema de Fermat, sabemos que esta observación es correcta: es decir, 
    \( 2^{n-1} \equiv 1 \pmod{n} \) siempre que \( n \) sea un primo impar. En segundo lugar, nunca encontraron 
    un número compuesto \( n \) para el cual se cumpliera esta congruencia. Sin embargo, los antiguos chinos 
    estaban solo parcialmente en lo correcto. Tenían razón al pensar que la congruencia se cumple si \( n \) 
    es primo, pero estaban equivocados al concluir que \( n \) debe ser primo si la congruencia se cumple.</p>

    <p>Desafortunadamente, existen enteros compuestos \( n \) tales que:</p>

    <p>\[ 2^{n-1} \equiv 1 \pmod{n} \]</p>

    <p>A estos enteros se les llama <strong>pseudoprimos en base 2</strong>.</p>

    <h3>Ejemplo 10</h3>

    <p>El número entero 341 es un pseudoprimo en base 2 porque es compuesto (\( 341 = 11 \cdot 31 \)) y, como 
    muestra el Ejercicio 37:</p>

    <p>\[ 2^{340} \equiv 1 \pmod{341} \]</p>

    <p>Podemos usar un entero distinto de 2 como base al estudiar pseudoprimos.</p>

    <h3>Definición 1</h3>

    <p>Sea \( b \) un entero positivo. Si \( n \) es un número entero positivo compuesto y \( b^{n-1} \equiv 1 \pmod{n} \), 
    entonces \( n \) se llama un pseudoprimo en base \( b \).</p>

    <p>Dado un entero positivo \( n \), determinar si \( 2^{n-1} \equiv 1 \pmod{n} \) es una prueba útil que ofrece 
    cierta evidencia sobre si \( n \) es primo. En particular:</p>

    <ul>
    <li>Si \( n \) satisface esta congruencia, entonces es primo o un pseudoprimo en base 2.</li>
    <li>Si \( n \) no la satisface, entonces es compuesto.</li>
    </ul>

    <p>Podemos realizar pruebas similares usando bases distintas de 2 para obtener más evidencia sobre si \( n \) es
    primo. Si \( n \) pasa todas estas pruebas, es primo o un pseudoprimo en todas las bases \( b \) elegidas.</p>

    <p>Además, entre los enteros positivos menores o iguales que un número real positivo \( x \), los pseudoprimos en
    base \( b \) (donde \( b \) es un entero positivo) son relativamente escasos en comparación con los primos. 
    Por ejemplo, entre los enteros menores que \( 10^{10} \), hay 455,052,512 primos, pero solo 14,884 pseudoprimos 
    en base 2.</p>

    <p>Desafortunadamente, no podemos distinguir entre primos y pseudoprimos simplemente eligiendo muchas bases, 
    porque existen números compuestos \( n \) que pasan todas las pruebas con bases \( b \) tales que \( \gcd(b, n) = 1 \).
    Esto nos lleva a la siguiente definición:</p>

    <h3>Definición 2</h3>

    <p>Un número entero compuesto \( n \) que satisface la congruencia \( b^{n-1} \equiv 1 \pmod{n} \) para 
    todo entero positivo \( b \) tal que \( \gcd(b, n) = 1 \) se llama un <strong>número de Carmichael</strong>. 
    (Estos números reciben su nombre de Robert Carmichael, quien los estudió a principios del siglo XX.)</p>

    <h3>Ejemplo 11</h3>

    <p>El número entero 561 es un número de Carmichael. Primero, notamos que 561 es compuesto porque:</p>

    <p>\[ 561 = 3 \cdot 11 \cdot 17 \]</p>

    <p>Luego, si \( \gcd(b, 561) = 1 \), entonces también se cumple que:</p>

    <p>\[ \gcd(b, 3) = \gcd(b, 11) = \gcd(b, 17) = 1 \]</p>

    <p>Aplicando el pequeño teorema de Fermat, tenemos:</p>

    <p>\[ b^2 \equiv 1 \pmod{3}, \quad b^{10} \equiv 1 \pmod{11}, \quad b^{16} \equiv 1 \pmod{17} \]</p>

    <p>Entonces:</p>

    <p>\[ b^{560} = (b^2)^{280} \equiv 1 \pmod{3}, \quad b^{560} = (b^{10})^{56} \equiv 1 \pmod{11}, \quad b^{560} = 
    (b^{16})^{35} \equiv 1 \pmod{17} \]</p>

    <p>Por el Ejercicio 29, se sigue que:</p>

    <p>\[ b^{560} \equiv 1 \pmod{561} \]</p>

    <p>para todo entero positivo \( b \) con \( \gcd(b, 561) = 1 \). Por lo tanto, 561 es un número de Carmichael.</p>

    <p>Aunque existen infinitos números de Carmichael, pueden diseñarse pruebas más refinadas (descritas en el 
    conjunto de ejercicios) que sirven de base para pruebas probabilísticas de primalidad eficientes. Estas pruebas 
    permiten mostrar rápidamente que un número dado es casi con certeza primo. Más precisamente, si un número no es
    primo, la probabilidad de que pase una serie de estas pruebas es muy cercana a 0.</p>

    <p>Estas pruebas de primalidad probabilísticas se describirán en el Capítulo 7, junto con los conceptos de 
    teoría de la probabilidad en los que se basan. Estas pruebas pueden (y de hecho se utilizan) para encontrar 
    primos grandes de manera extremadamente rápida con computadoras.</p>

    <h2>4.4.7 Raíces Primitivas y Logaritmos Discretos</h2>
    <p>En el conjunto de los números reales positivos, si \( b > 1 \) y \( x = b^y \), decimos que \( y \) 
    es el logaritmo de \( x \) en base \( b \). Aquí mostraremos que también podemos definir el concepto de 
    logaritmos módulo \( p \) de enteros positivos, donde \( p \) es un número primo. Antes de hacerlo, necesitamos 
    una definición.</p>

    <h3>Definición 3</h3>
    <p>Una raíz primitiva módulo un primo \( p \) es un entero \( r \) en \( \mathbb{Z}_p \) tal que todo 
    elemento no nulo de \( \mathbb{Z}_p \) es una potencia de \( r \).</p>

 
    </form>
</div>




<div class="seccion derecha">
    <form action="./segundo.php" method="POST" onsubmit="handleSubmit(event)" autocomplete="off">
    
    <h3>Ejemplo 12</h3>
    <p>Determina si 2 y 3 son raíces primitivas módulo 11.</p>

    <h4>Solución:</h4>
    <p>Cuando calculamos las potencias de 2 en \( \mathbb{Z}_{11} \), obtenemos:</p>
    <p>
        \( 2^1 = 2, \, 2^2 = 4, \, 2^3 = 8, \, 2^4 = 5, \, 2^5 = 10, \, 2^6 = 9, \, 2^7 = 7, \, 2^8 = 3, 
        \, 2^9 = 6, \, 2^{10} = 1 \)
    </p>
    <p>Como todo elemento no nulo de \( \mathbb{Z}_{11} \) es una potencia de 2, 2 es una raíz primitiva de 11.</p>

    <p>Al calcular las potencias de 3 módulo 11:</p>
    <p>
        \( 3^1 = 3, \, 3^2 = 9, \, 3^3 = 5, \, 3^4 = 4, \, 3^5 = 1 \)
    </p>
    <p>Este patrón se repite al calcular potencias más altas de 3. Como no todos los elementos no nulos de 
    \( \mathbb{Z}_{11} \) son potencias de 3, concluimos que 3 no es una raíz primitiva de 11.</p>

    <p>Un hecho importante en teoría de números es que existe una raíz primitiva módulo \( p \) para todo número 
        primo \( p \). Remitimos al lector a [Ro10] para una demostración de este hecho.</p>

    <p>Supongamos que \( p \) es primo y que \( r \) es una raíz primitiva módulo \( p \). Si \( a \) es un entero 
    entre 1 y \( p - 1 \), es decir, un elemento no nulo de \( \mathbb{Z}_p \), sabemos que existe un único 
    exponente \( e \) tal que \( r^e \equiv a \mod p \).</p>

    <h3>Definición 4</h3>
    <p>Supón que \( p \) es un primo, \( r \) es una raíz primitiva módulo \( p \), y \( a \) es un entero 
    entre 1 y \( p - 1 \) inclusive. Si \( r^e \equiv a \mod p \) y \( 0 \leq e \leq p - 1 \), decimos que \( e \) 
    es el logaritmo discreto de \( a \) módulo \( p \) en base \( r \) y escribimos:</p>
    <p>\( \log_r a = e \) (donde el módulo \( p \) se sobreentiende).</p>

    <h3>Ejemplo 13</h3>
    <p>Encuentra los logaritmos discretos de 3 y 5 módulo 11 en base 2.</p>

    <h4>Solución:</h4>
    <p>Cuando calculamos las potencias de 2 módulo 11 en el Ejemplo 12, encontramos que:</p>
    <p>
        \( 2^8 \equiv 3 \mod 11 \) y \( 2^4 \equiv 5 \mod 11 \)
    </p>
    <p>Por lo tanto, los logaritmos discretos de 3 y 5 módulo 11 en base 2 son 8 y 4, respectivamente. Escribimos:</p>
    <p>\( \log_2 3 = 8 \) y \( \log_2 5 = 4 \) (donde el módulo 11 se entiende aunque no se indique explícitamente en la notación).</p>

    <p><strong>El problema del logaritmo discreto</strong></p>
    <p>El problema del logaritmo discreto toma como entrada un primo \( p \), una raíz primitiva \( r \) módulo \( p \), y un entero positivo \( a \in \mathbb{Z}_p \); su salida es el logaritmo discreto de \( a \) módulo \( p \) en base \( r \).</p>

    <p>Aunque este problema pueda no parecer tan difícil, resulta que no se conoce ningún algoritmo de tiempo polinomial para resolverlo. La dificultad de este problema desempeña un papel importante en la criptografía, como veremos en la Sección 4.6.</p>
    <hr>
    <strong>parentesis</strong>
    <h2>El Proceso de Calcular las Potencias de un Número Módulo \( p \)</h2>
    <p>El proceso de calcular las potencias de un número módulo \( p \) termina cuando el residuo es 1, porque eso indica que hemos completado un ciclo y que las potencias comenzarán a repetirse a partir de ese punto.</p>

    <p>Este concepto está relacionado con el orden de un número \( r \) módulo \( p \). El orden es el menor exponente \( e \) tal que:</p>
    <p>\( r^e \equiv 1 \mod p \)</p>
    
    <p>Cuando encontramos que \( r^e \equiv 1 \mod p \), sabemos que las siguientes potencias de \( r \) empezarán a repetirse. Es decir:</p>
    <p>\( r^{e+1} = r \times r^e \equiv r \times 1 = r \mod p \)</p>

    <p>\( r^{e+2} = r^2 \mod p \)</p>

    <p>Y así sucesivamente...</p>

    <h3>Ejemplo:</h3>
    <p>Por ejemplo, en tu caso con \( r = 3 \) y \( p = 11 \), vimos que \( 3^5 \equiv 1 \mod 11 \). Esto significa que las potencias de 3 módulo 11 se repetirán después de \( 3^5 \), así que no es necesario seguir calculando más potencias.</p>

    <p>Entonces, sí, el proceso "termina" cuando el residuo es 1, porque a partir de ahí el ciclo de los residuos se repite.</p>

    <hr>


    <h2>4.4.4 Aritmética Computacional con Enteros Grandes</h2>

    <p>Supongamos que \( m_1, m_2, \ldots, m_n \) son módulos relativamente primos dos a dos y que \( m \) es su producto. 
    Por el teorema chino del resto, podemos demostrar (ver Ejercicio 28) que un entero \( a \) con \( 0 \leq a < m \) puede 
    representarse de forma única mediante la n-tupla compuesta por sus residuos al dividirlo entre \( m_i \), 
    para \( i = 1, 2, \ldots, n \). Es decir, podemos representar \( a \) de forma única como:</p>

    <p>
    \[
    (a \bmod m_1, a \bmod m_2, \ldots, a \bmod m_n)
    \]
    </p>

    <h3>Ejemplo 7</h3>
    <p>¿Cuáles son los pares utilizados para representar los enteros no negativos menores que 12 cuando 
    se representan por el par ordenado donde el primer componente es el residuo del entero al dividirlo 
    entre 3 y el segundo componente es el residuo al dividirlo entre 4?</p>

    <p><strong>Solución:</strong> Tenemos las siguientes representaciones, obtenidas al encontrar el residuo de cada 
    entero al dividirlo entre 3 y entre 4:</p>

    <p>
    0 = (0, 0) &nbsp;&nbsp; 4 = (1, 0) &nbsp;&nbsp; 8 = (2, 0)<br>
    1 = (1, 1) &nbsp;&nbsp; 5 = (2, 1) &nbsp;&nbsp; 9 = (0, 1)<br>
    2 = (2, 2) &nbsp;&nbsp; 6 = (0, 2) &nbsp;&nbsp; 10 = (1, 2)<br>
    3 = (0, 3) &nbsp;&nbsp; 7 = (1, 3) &nbsp;&nbsp; 11 = (2, 3)
    </p>

    <p>Para realizar operaciones aritméticas con enteros grandes, seleccionamos módulos \( m_1, m_2, \ldots, m_n \), 
    donde cada \( m_i \) es un entero mayor que 2, \( \gcd(m_i, m_j) = 1 \) siempre que \( i \ne j \), y 
    \( m = m_1 m_2 \cdots m_n \) es mayor que los resultados de las operaciones aritméticas que queremos 
    realizar.</p>

    <p>Una vez que hemos seleccionado nuestros módulos, realizamos operaciones aritméticas con enteros grandes 
    efectuando operaciones componente a componente sobre las n-tuplas que representan estos enteros usando sus 
    residuos al dividirlos por \( m_i \), para \( i = 1, 2, \ldots, n \). Una vez calculado el valor de cada 
    componente en el resultado, recuperamos su valor resolviendo un sistema de \( n \) congruencias módulo 
    \( m_i \), para \( i = 1, 2, \ldots, n \).</p>

    <p>Este método de realizar aritmética con enteros grandes tiene varias ventajas importantes. Primero, puede 
    utilizarse para realizar aritmética con enteros más grandes de lo que normalmente se puede manejar en una 
    computadora. Segundo, los cálculos con respecto a los diferentes módulos pueden hacerse en paralelo, acelerando 
    la aritmética.</p>

    <h3>Ejemplo 8</h3>
    <p>Supongamos que realizar aritmética con enteros menores que 100 en cierto procesador es mucho más rápido 
    que hacerla con enteros más grandes. Podemos restringir casi todos nuestros cálculos a enteros menores que 100 
    si representamos enteros usando sus residuos módulo enteros relativamente primos dos a dos menores que 100. 
    Por ejemplo, podemos usar los módulos 99, 98, 97 y 95. (Estos enteros son relativamente primos dos a dos, ya 
    que ningún par tiene un factor común mayor que 1.)</p>

    <p>Por el teorema chino del resto, todo entero no negativo menor que 
    \( 99 \cdot 98 \cdot 97 \cdot 95 = 89,\!403,\!930 \) puede representarse de forma única mediante sus 
    residuos al dividirlo por estos cuatro módulos.</p>

    <p>Por ejemplo, representamos 123,684 como (33, 8, 9, 89), porque:</p>

    <ul>
    <li>123,684 mod 99 = 33</li>
    <li>123,684 mod 98 = 8</li>
    <li>123,684 mod 97 = 9</li>
    <li>123,684 mod 95 = 89</li>
    </ul>

    <p>De forma similar, representamos 413,456 como (32, 92, 42, 16).</p>

    <p>Para hallar la suma de 123,684 y 413,456, trabajamos con estas 4-tuplas en lugar de con los dos enteros 
    directamente. Sumamos las 4-tuplas componente a componente y reducimos cada componente con respecto al 
    módulo apropiado. Esto da como resultado:</p>

    <p>
    \[
    (33, 8, 9, 89) + (32, 92, 42, 16) = (65 \bmod 99, 100 \bmod 98, 51 \bmod 97, 105 \bmod 95) = (65, 2, 51, 10)
    \]
    </p>

    <p>Para hallar la suma, es decir, el entero representado por (65, 2, 51, 10), necesitamos resolver el sistema 
    de congruencias:</p>

    <p>
    \[
    \begin{aligned}
    x &\equiv 65 \pmod{99} \\
    x &\equiv 2 \pmod{98} \\
    x &\equiv 51 \pmod{97} \\
    x &\equiv 10 \pmod{95}
    \end{aligned}
    \]
    </p>

    <p>Puede demostrarse (ver Ejercicio 53) que 537,140 es la única solución no negativa de este sistema 
    menor que 89,403,930. Por consiguiente, 537,140 es la suma. Nótese que solo cuando necesitamos recuperar 
    el entero representado por (65, 2, 51, 10) es necesario realizar aritmética con enteros mayores que 100.</p>

    <p>Elecciones particularmente buenas para los módulos usados en aritmética con enteros grandes son conjuntos 
    de enteros de la forma \( 2^k - 1 \), donde \( k \) es un entero positivo, ya que es fácil realizar aritmética 
    binaria módulo estos enteros, y también es fácil encontrar conjuntos de tales enteros que sean relativamente 
    primos dos a dos. 
    (La segunda razón es consecuencia del hecho de que \( \gcd(2^a - 1, 2^b - 1) = 2^{\gcd(a,b)} - 1 \), como 
    muestra el Ejercicio 37 de la Sección 4.3.)</p>

    <p>Supongamos, por ejemplo, que podemos realizar aritmética con enteros menores que \( 2^{35} \) fácilmente 
    en nuestra computadora, pero que trabajar con enteros más grandes requiere procedimientos especiales. Podemos 
    usar módulos relativamente primos dos a dos menores que \( 2^{35} \) para realizar aritmética con enteros tan 
    grandes como su producto. 
    Por ejemplo, como muestra el Ejercicio 38 de la Sección 4.3, los enteros 
    \( 2^{35} - 1, 2^{34} - 1, 2^{33} - 1, 2^{31} - 1, 2^{29} - 1 \) y \( 2^{23} - 1 \) son 
    relativamente primos dos a dos. 
    Como el producto de estos seis módulos excede \( 2^{184} \), podemos realizar aritmética con enteros tan grandes 
    como \( 2^{184} \) (mientras los resultados no excedan este número) realizando aritmética módulo cada uno de estos 
    seis módulos, ninguno de los cuales excede \( 2^{35} \).</p>

    </form>
</div>

<div class="centered-container">
    <a
        name="siguiente"
        id="siguiente"
        class="btn btn-primary"
        href="segundo.php"
        role="button"
        width="50px"
        height="50px"
    >Siguiente</a>
</div>
</body>
</html>
