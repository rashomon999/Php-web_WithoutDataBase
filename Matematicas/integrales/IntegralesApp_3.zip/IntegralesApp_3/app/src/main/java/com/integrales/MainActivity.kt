package com.integrales

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.integrales.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnB1.setOnClickListener { abrirQuiz("b1") }
        binding.btnB2.setOnClickListener { abrirQuiz("b2") }
        binding.btnB3.setOnClickListener { abrirQuiz("b3") }
        binding.btnB4.setOnClickListener { abrirQuiz("b4") }
        binding.btnB5.setOnClickListener { abrirQuiz("b5") }
        binding.btnTrig.setOnClickListener { abrirQuiz("trig") }

        // Selector de idioma (per-app locale: se guarda automáticamente)
        binding.btnIdioma.setOnClickListener {
            val opciones = arrayOf("Español", "English")
            AlertDialog.Builder(this)
                .setTitle(getString(R.string.idioma_titulo))
                .setItems(opciones) { _, cual ->
                    val etiqueta = if (cual == 0) "es" else "en"
                    AppCompatDelegate.setApplicationLocales(
                        LocaleListCompat.forLanguageTags(etiqueta)
                    )
                }
                .show()
        }
    }

    private fun abrirQuiz(nombre: String) {
        val intent = Intent(this, QuizActivity::class.java)
        intent.putExtra("quiz", nombre)
        startActivity(intent)
    }
}
