<?php
/* ==========================================================================
   CiberSeguridad / Fundamentos  —  CIA, no repudio y vocabulario
   Fuente: notas_1.pdf (Tab 1) y notas_2.pdf (pregunta 2)
   ========================================================================== */

require_once __DIR__ . '/../motor.php';

$SOLUCIONES = [
    /* --- los cinco conceptos: dada la definicion, el termino --- */
    1  => ['ciberseguridad', 'cybersecurity'],
    2  => ['confidencialidad', 'confidentiality'],
    3  => ['disponibilidad', 'availability'],
    4  => ['integridad', 'integrity'],
    5  => ['no repudio', 'nonrepudiation', 'no-repudio'],

    /* --- las dos implementaciones del no repudio --- */
    6  => ['firmas digitales', 'firma digital', 'digital signatures'],
    7  => ['registros de transacciones', 'registro de transacciones', 'transaction logs'],

    /* --- que protege cada uno (acceso / modificacion / acceso oportuno) --- */
    8  => ['confidencialidad'],
    9  => ['integridad'],
    10 => ['disponibilidad'],

    /* --- seguridad de la informacion vs ciberseguridad --- */
    11 => ['seguridad de la informacion', 'information security'],
    12 => ['ciberseguridad', 'cybersecurity'],

    /* --- vocabulario ES -> EN --- */
    13 => ['confidentiality'],
    14 => ['integrity'],
    15 => ['availability'],
    16 => ['nonrepudiation', 'non-repudiation'],
    17 => ['threats'],
    18 => ['information assets'],
    19 => ['unauthorized'],
    20 => ['disclosure'],
    21 => ['encryption'],
    22 => ['access controls', 'access control'],
    23 => ['digital signatures', 'digital signature'],
    24 => ['transaction logs', 'transaction log'],
    25 => ['interconnected systems', 'interconnected'],
    26 => ['modification'],

    /* --- vocabulario EN -> ES --- */
    27 => ['divulgacion'],
    28 => ['activos de informacion', 'activo de informacion'],
    29 => ['cifrado'],
    30 => ['controles de acceso', 'control de acceso'],
];

/* todos son texto: no importan mayusculas ni tildes */
$TEXTO = range(1, 30);

$MULTIPLE = [
    'm1' => [
        'texto'    => 'Un atacante lee la nomina de la empresa sin permiso, pero no cambia nada. &iquest;Que principio se rompio?',
        'opciones' => [
            'a' => 'Integridad',
            'b' => 'Confidencialidad',
            'c' => 'Disponibilidad',
            'd' => 'No repudio'
        ],
        'correcta' => 'b',
        'porque'   => 'Confidencialidad = proteger la informacion del <b>acceso o divulgacion</b> no autorizados. Como no modifico nada, la integridad sigue intacta.'
    ],
    'm2' => [
        'texto'    => 'Un empleado altera las cifras de un reporte financiero. &iquest;Que principio se rompio?',
        'opciones' => [
            'a' => 'Confidencialidad',
            'b' => 'Disponibilidad',
            'c' => 'Integridad',
            'd' => 'Anonimato'
        ],
        'correcta' => 'c',
        'porque'   => 'Integridad = proteger la informacion de la <b>modificacion</b> no autorizada, para que siga siendo precisa, completa y confiable.'
    ],
    'm3' => [
        'texto'    => 'Un ataque tumba el portal del banco y nadie puede entrar durante seis horas. La informacion no se filtro ni se altero. &iquest;Que principio se rompio?',
        'opciones' => [
            'a' => 'Disponibilidad',
            'b' => 'Confidencialidad',
            'c' => 'Integridad',
            'd' => 'Ninguno, no hubo robo'
        ],
        'correcta' => 'a',
        'porque'   => 'Disponibilidad = acceso <b>oportuno y confiable</b> a la informacion y a los sistemas cuando los usuarios autorizados los necesitan. Un DoS ataca exactamente esto.'
    ],
    'm4' => [
        'texto'    => 'Alguien firma digitalmente un contrato y despues dice que el no lo envio. La firma prueba que si fue el. &iquest;Que servicio esta actuando?',
        'opciones' => [
            'a' => 'Confidencialidad',
            'b' => 'Disponibilidad',
            'c' => 'No repudio',
            'd' => 'Integridad'
        ],
        'correcta' => 'c',
        'porque'   => 'No repudio = la garantia de que una persona <b>no puede negar</b> haber enviado o recibido informacion. Se implementa con firmas digitales y registros de transacciones.'
    ],
    'm5' => [
        'texto'    => 'Segun los apuntes, &iquest;cual de estas afirmaciones es la correcta?',
        'opciones' => [
            'a' => 'La ciberseguridad y la seguridad de la informacion son sinonimos',
            'b' => 'La ciberseguridad es un <b>subconjunto</b> de la seguridad de la informacion',
            'c' => 'La seguridad de la informacion es un subconjunto de la ciberseguridad',
            'd' => 'Son disciplinas independientes que no se solapan'
        ],
        'correcta' => 'b',
        'porque'   => 'La seguridad de la informacion protege <b>toda</b> la informacion (papel, digital, e incluso la que esta en la cabeza de las personas). La ciberseguridad se concentra en la informacion digital.'
    ],
    'm6' => [
        'texto'    => 'Un expediente medico impreso guardado en un archivador con llave. &iquest;Que lo protege?',
        'opciones' => [
            'a' => 'Solo la ciberseguridad',
            'b' => 'La seguridad de la informacion, porque no es informacion digital',
            'c' => 'Ninguna de las dos, el papel no cuenta',
            'd' => 'Las dos por igual'
        ],
        'correcta' => 'b',
        'porque'   => 'Es justo el ejemplo que separa los dos terminos: papel = seguridad de la informacion, no ciberseguridad.'
    ],
    'm7' => [
        'texto'    => 'En la definicion de ciberseguridad, la informacion se protege en tres estados. &iquest;Cuales son?',
        'opciones' => [
            'a' => 'Creada, leida y borrada',
            'b' => 'Procesada, almacenada y transportada',
            'c' => 'Publica, privada y secreta',
            'd' => 'Cifrada, firmada y respaldada'
        ],
        'correcta' => 'b',
        'porque'   => '&laquo;...amenazas a la informacion que es <b>procesada, almacenada y transportada</b> por sistemas de informacion interconectados&raquo;. Cae tal cual en el parcial.'
    ],
];

iniciar($SOLUCIONES, $MULTIPLE, $TEXTO);
cabecera('1 · Fundamentos: CIA y no repudio', 'notas_1 (Tab 1) · vocabulario EN/ES');
?>

<div class="card">
  <h2>De que va esto</h2>
  <p>La primera lectura define <b>cinco palabras</b> y nada mas. Todo el resto del curso se
     cuelga de ellas, asi que hay que tenerlas exactas, en español y en ingles.</p>
  <div class="nota">
    <b>Como se corrige.</b> En esta pagina las respuestas son <b>texto</b>: no importan
    las mayusculas ni las tildes. <code>No Repudio</code>, <code>no repudio</code> y
    <code>nonrepudiation</code> se aceptan igual. Pulsa <b>Enter</b> para verificar.
  </div>
</div>


<div class="card">
  <h2>1. La definicion, y tu pones el nombre</h2>
  <p>Lee cada definicion y escribe el termino que le corresponde.</p>

  <?php linea(1, 'La proteccion de los <b>activos de informacion</b> mediante la identificacion y el tratamiento de las amenazas a la informacion procesada, almacenada y transportada por sistemas interconectados.', 'escribe el termino...'); ?>
  <?php linea(2, 'La proteccion de la informacion contra el <b>acceso o la divulgacion</b> no autorizados. Solo las personas autorizadas pueden ver informacion sensible.', 'escribe el termino...'); ?>
  <?php linea(3, 'El acceso <b>oportuno y confiable</b> a la informacion y a los sistemas siempre que los usuarios autorizados los necesiten.', 'escribe el termino...'); ?>
  <?php linea(4, 'La proteccion de la informacion contra <b>modificaciones</b> no autorizadas. Garantiza que siga siendo precisa, completa y confiable.', 'escribe el termino...'); ?>
  <?php linea(5, 'La garantia de que una persona <b>no puede negar</b> haber enviado o recibido informacion.', 'escribe el termino...'); ?>

  <p>El no repudio se implementa normalmente con dos cosas:</p>
  <?php linea(6, 'la primera (lo que firma el remitente)', 'escribe el termino...'); ?>
  <?php linea(7, 'la segunda (el rastro que deja el sistema)', 'escribe el termino...'); ?>

  <?php enviar(); ?>
</div>


<div class="card">
  <h2>2. Que protege cada uno</h2>
  <p>Los tres primeros forman la <b>triada CIA</b>. La forma rapida de no confundirlos:</p>

  <table class="datos">
    <tr><th>Principio</th><th>Protege contra...</th><th>La pregunta que responde</th></tr>
    <tr><td>Confidencialidad</td><td>acceso / divulgacion</td><td>&iquest;quien puede <b>ver</b> esto?</td></tr>
    <tr><td>Integridad</td><td>modificacion</td><td>&iquest;esto sigue siendo <b>correcto</b>?</td></tr>
    <tr><td>Disponibilidad</td><td>interrupcion</td><td>&iquest;puedo <b>usarlo</b> cuando lo necesito?</td></tr>
  </table>

  <p>Ahora al reves: dado el ataque, di que principio se rompe.</p>
  <?php linea(8,  'Alguien <b>ve</b> informacion que no le corresponde', 'principio...'); ?>
  <?php linea(9,  'Alguien <b>altera</b> un dato sin autorizacion', 'principio...'); ?>
  <?php linea(10, 'El sistema <b>se cae</b> y los usuarios legitimos no pueden entrar', 'principio...'); ?>

  <?php mc('m1'); ?>
  <?php mc('m2'); ?>
  <?php mc('m3'); ?>
  <?php mc('m4'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>3. Seguridad de la informacion vs. ciberseguridad</h2>
  <p>Esta es la pregunta 2 de los apuntes y se responde con una sola frase:
     una es un <b>subconjunto</b> de la otra.</p>

  <?php linea(11, 'La <b>mas amplia</b>: protege todo tipo de informacion, incluida la de papel y la que esta en la mente de las personas', 'escribe el termino...'); ?>
  <?php linea(12, 'La <b>mas estrecha</b>: se enfoca en la informacion almacenada o transmitida de forma digital', 'escribe el termino...'); ?>

  <?php mc('m5'); ?>
  <?php mc('m6'); ?>
  <?php mc('m7'); ?>
  <?php enviar(); ?>
</div>


<div class="card">
  <h2>4. Vocabulario — español &rarr; ingles</h2>
  <p>La clase se discute en ingles, asi que estas 14 palabras hay que tenerlas en los dos idiomas.</p>

  <table class="datos">
    <tr><th>Español</th><th>English</th></tr>
    <tr><td>Confidencialidad</td><td><?php hueco(13, 18); ?></td></tr>
    <tr><td>Integridad</td><td><?php hueco(14, 18); ?></td></tr>
    <tr><td>Disponibilidad</td><td><?php hueco(15, 18); ?></td></tr>
    <tr><td>No repudio</td><td><?php hueco(16, 18); ?></td></tr>
    <tr><td>Amenazas</td><td><?php hueco(17, 18); ?></td></tr>
    <tr><td>Activos de informacion</td><td><?php hueco(18, 22); ?></td></tr>
    <tr><td>No autorizado</td><td><?php hueco(19, 18); ?></td></tr>
    <tr><td>Divulgacion</td><td><?php hueco(20, 18); ?></td></tr>
    <tr><td>Cifrado</td><td><?php hueco(21, 18); ?></td></tr>
    <tr><td>Controles de acceso</td><td><?php hueco(22, 22); ?></td></tr>
    <tr><td>Firmas digitales</td><td><?php hueco(23, 22); ?></td></tr>
    <tr><td>Registros de transacciones</td><td><?php hueco(24, 22); ?></td></tr>
    <tr><td>Sistemas interconectados</td><td><?php hueco(25, 24); ?></td></tr>
    <tr><td>Modificacion</td><td><?php hueco(26, 18); ?></td></tr>
  </table>

  <?php enviar(); ?>
</div>


<div class="card">
  <h2>5. Vocabulario — ingles &rarr; español</h2>
  <p>Las cuatro que mas se confunden, en el sentido contrario.</p>

  <table class="datos">
    <tr><th>English</th><th>Español</th></tr>
    <tr><td>Disclosure</td><td><?php hueco(27, 22); ?></td></tr>
    <tr><td>Information assets</td><td><?php hueco(28, 24); ?></td></tr>
    <tr><td>Encryption</td><td><?php hueco(29, 18); ?></td></tr>
    <tr><td>Access controls</td><td><?php hueco(30, 24); ?></td></tr>
  </table>

  <?php enviar('Verificar todo el cuestionario'); ?>
</div>

<?php
pie('', '../Riesgos/index.php');
