package com.integrales

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * WebView que renderiza fórmulas LaTeX con KaTeX (incluido en assets, funciona sin internet).
 * Equivalente al MathJax de la versión web.
 */
@SuppressLint("SetJavaScriptEnabled")
class MathView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : WebView(context, attrs) {

    private var listo = false
    private var pendiente: String? = null

    init {
        settings.javaScriptEnabled = true
        setBackgroundColor(Color.TRANSPARENT)
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                listo = true
                pendiente?.let {
                    setLatex(it)
                    pendiente = null
                }
            }
        }
        loadUrl("file:///android_asset/katex/render.html")
    }

    fun setLatex(latex: String) {
        if (!listo) {
            pendiente = latex
            return
        }
        val escapado = latex
            .replace("\\", "\\\\")
            .replace("'", "\\'")
            .replace("\n", " ")
        evaluateJavascript("setLatex('$escapado')", null)
    }
}
