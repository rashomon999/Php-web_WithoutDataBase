<?php
$libros = [
    [
        'nombre' => 'Arquitectura de Computadores',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'arquitecturaComputadores/Menu.php'
    ],
    [
        'nombre' => 'Compunet',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'compunet/Menu.php'
    ],
    [
        'nombre' => 'Discretas',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'discretas/menu.php'
    ],
    [
        'nombre' => 'Estadística',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'Estadistica/Menu.php'
    ],
    [
        'nombre' => 'Ingesoft',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'ingeSoft/Menu.php'
    ],
    [
        'nombre' => 'Inglés',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'Ingles/Menu.php'
    ],
    [
        'nombre' => 'Java',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'java/Menu.php'
    ],
    [
        'nombre' => 'Matemáticas',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'Matematicas/Menu.php'
    ],
    [
        'nombre' => 'Modulación Financiera',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'ModulacionFinanciera/Menu.php'
    ],
    [
        'nombre' => 'Música',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'musica/Menu.php'
    ],
    [
        'nombre' => 'Scala',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'scala/Menu.php'
    ],
    [
        'nombre' => 'Sistema de Datos',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'SistemaDatos/Menu.php'
    ],
    [
        'nombre' => 'Sistemas Operativos',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'sistemas_operativos/Menu.php'
    ],
    [
        'nombre' => 'Trading',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'Trading/Menu.php'
    ],
    [
        'nombre' => 'CiberSeguridad',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'CiberSeguridad/Menu.php'
    ],
    [
        'nombre' => 'APO',
        'imagen' => 'fondo.jpg',
        'categoria' => 'principal',
        'link' => 'APO/Menu.php'
    ],
    [
        'nombre' => 'Física',
        'imagen' => 'fondo.jpg',
        'categoria' => 'especial',
        'link' => 'fisica/Menu.php'
    ],
    [
        'nombre' => 'Contabilidad',
        'imagen' => 'fondo.jpg',
        'categoria' => 'especial',
        'link' => 'contabilidad/Menu.php'
    ],
    [
        'nombre' => 'Django',
        'imagen' => 'fondo.jpg',
        'categoria' => 'especial',
        'link' => 'Django/Menu.php'
    ],
    [
        'nombre' => 'Operaciones Básicas',
        'imagen' => 'fondo.jpg',
        'categoria' => 'especial',
        'link' => 'operaciones_basicas/index.php'
    ],
    [
        'nombre' => 'Transhumantes',
        'imagen' => 'fondo.jpg',
        'categoria' => 'especial',
        'link' => 'transhumantes/Menu.php'
    ],
    [
        'nombre' => 'Estadística Especial',
        'imagen' => 'fondo.jpg',
        'categoria' => 'especial',
        'link' => 'Estadistica/Menu.php'
    ],
];
