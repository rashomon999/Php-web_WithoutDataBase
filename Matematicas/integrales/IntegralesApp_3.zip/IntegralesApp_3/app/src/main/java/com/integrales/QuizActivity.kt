package com.integrales

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.integrales.databinding.ActivityQuizBinding

class QuizActivity : AppCompatActivity() {

    private lateinit var binding: ActivityQuizBinding
    private lateinit var preguntas: List<Pregunta>
    private lateinit var respuestasUsuario: Array<String>
    private lateinit var estados: Array<String> // "", "correcto", "incorrecto"
    private var indice = 0
    private var cargandoPregunta = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuizBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val nombreQuiz = intent.getStringExtra("quiz") ?: "basicas"
        preguntas = Quiz.obtener(nombreQuiz)
        respuestasUsuario = Array(preguntas.size) { "" }
        estados = Array(preguntas.size) { "" }

        binding.tvTitulo.text = getString(tituloRes(nombreQuiz))

        binding.btnVerificar.setOnClickListener { verificar() }
        binding.btnSolucion.setOnClickListener { mostrarSolucion() }
        binding.btnSiguiente.setOnClickListener { siguiente() }
        binding.btnAnterior.setOnClickListener { anterior() }
        binding.btnMenu.setOnClickListener { finish() }

        configurarBarraMatematica()

        // Vista previa en vivo (equivale a actualizarFormula() de tu web)
        binding.etRespuesta.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!cargandoPregunta) {
                    binding.wvPrevia.setLatex(s?.toString() ?: "")
                }
            }
        })

        mostrarPregunta()
    }

    private fun tituloRes(nombre: String): Int = when (nombre) {
        "b2" -> R.string.quiz_b2
        "b3" -> R.string.quiz_b3
        "b4" -> R.string.quiz_b4
        "b5" -> R.string.quiz_b5
        "trig" -> R.string.quiz_trig
        else -> R.string.quiz_b1
    }

    /**
     * Barra de símbolos estilo Symbolab: cada botón inserta la plantilla LaTeX
     * en la posición del cursor y deja el cursor dentro del primer hueco.
     */
    private fun configurarBarraMatematica() {
        binding.btnFrac.setOnClickListener { insertar("\\frac{}{}", 6) }
        binding.btnPot.setOnClickListener { insertar("^{}", 2) }
        binding.btnRaiz.setOnClickListener { insertar("\\sqrt{}", 6) }
        binding.btnParen.setOnClickListener { insertar("()", 1) }
        binding.btnAbs.setOnClickListener { insertar("||", 1) }
        binding.btnLn.setOnClickListener { insertar("Ln||", 3) }
        binding.btnMasC.setOnClickListener {
            val et = binding.etRespuesta
            et.text.append("+C")
            et.setSelection(et.text.length)
            et.requestFocus()
        }
        // ⇥ : salta al siguiente hueco (después de }, | o ) )
        binding.btnSalto.setOnClickListener {
            val et = binding.etRespuesta
            val texto = et.text.toString()
            val desde = et.selectionStart.coerceAtLeast(0)
            val idx = texto.indexOfAny(charArrayOf('}', '|', ')'), desde)
            et.setSelection(if (idx >= 0) idx + 1 else texto.length)
            et.requestFocus()
        }
    }

    private fun insertar(plantilla: String, offsetCursor: Int) {
        val et = binding.etRespuesta
        val pos = et.selectionStart.coerceAtLeast(0)
        et.text.insert(pos, plantilla)
        et.setSelection(pos + offsetCursor)
        et.requestFocus()
    }

    private fun guardarActual() {
        respuestasUsuario[indice] = binding.etRespuesta.text.toString()
    }

    private fun mostrarPregunta() {
        cargandoPregunta = true
        val p = preguntas[indice]

        binding.tvProgreso.text = getString(R.string.progreso, indice + 1, preguntas.size)

        // El enunciado se guarda como clave para poder traducirlo
        val textoEnunciado = when (p.enunciado) {
            "prop" -> getString(R.string.prop_integrales)
            "npregunta" -> getString(R.string.pregunta_n)
            else -> p.enunciado
        }
        if (textoEnunciado.isNotEmpty()) {
            binding.tvEnunciado.text = textoEnunciado
            binding.tvEnunciado.visibility = View.VISIBLE
        } else {
            binding.tvEnunciado.visibility = View.GONE
        }

        binding.wvPregunta.setLatex(p.latex)
        binding.etRespuesta.setText(respuestasUsuario[indice])
        binding.wvPrevia.setLatex(respuestasUsuario[indice])
        binding.wvSolucion.visibility = View.GONE
        binding.llPasos.visibility = View.GONE
        binding.llPasos.removeAllViews()
        pintarEstado(estados[indice])

        binding.btnAnterior.visibility = if (indice == 0) View.INVISIBLE else View.VISIBLE
        binding.btnSiguiente.text = getString(
            if (indice == preguntas.size - 1) R.string.finalizar else R.string.siguiente
        )

        cargandoPregunta = false
    }

    private fun verificar() {
        guardarActual()
        val p = preguntas[indice]
        val respuesta = respuestasUsuario[indice]

        estados[indice] = when {
            respuesta.isBlank() -> ""
            Quiz.esCorrecta(p, respuesta) -> "correcto"
            else -> "incorrecto"
        }
        pintarEstado(estados[indice])
    }

    private fun pintarEstado(estado: String) {
        when (estado) {
            "correcto" -> {
                binding.tvResultado.text = getString(R.string.correcto)
                binding.tvResultado.setTextColor(Color.parseColor("#2E7D32"))
            }
            "incorrecto" -> {
                binding.tvResultado.text = getString(R.string.incorrecto)
                binding.tvResultado.setTextColor(Color.parseColor("#C62828"))
            }
            else -> binding.tvResultado.text = ""
        }
    }

    private fun mostrarSolucion() {
        val p = preguntas[indice]
        binding.etRespuesta.setText(p.aceptadas.first())
        binding.tvResultado.text = getString(R.string.solucion_label)
        binding.tvResultado.setTextColor(Color.parseColor("#1565C0"))
        binding.wvSolucion.visibility = View.VISIBLE
        binding.wvSolucion.setLatex(p.solucion)
        estados[indice] = ""
        mostrarPasos(p)
    }

    /** Si la pregunta tiene explicación, se muestra debajo de la solución. */
    private fun mostrarPasos(p: Pregunta) {
        binding.llPasos.removeAllViews()
        if (p.pasos.isEmpty()) {
            binding.llPasos.visibility = View.GONE
            return
        }
        binding.llPasos.visibility = View.VISIBLE
        val densidad = resources.displayMetrics.density

        val titulo = TextView(this)
        titulo.text = getString(R.string.explicacion_titulo)
        titulo.setTypeface(null, Typeface.BOLD)
        titulo.textSize = 16f
        titulo.setTextColor(Color.parseColor("#1565C0"))
        binding.llPasos.addView(titulo)

        for (paso in p.pasos) {
            val tv = TextView(this)
            tv.text = getString(claveDePaso(paso.clave))
            tv.textSize = 14f
            tv.setTextColor(Color.parseColor("#424242"))
            tv.setPadding(0, (12 * densidad).toInt(), 0, 0)
            binding.llPasos.addView(tv)

            val mv = MathView(this)
            mv.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (110 * densidad).toInt()   // alto suficiente para ∫ con fracciones
            )
            mv.setLatex(paso.latex)
            binding.llPasos.addView(mv)
        }
    }

    private fun claveDePaso(clave: String): Int = when (clave) {
        "sustitucion" -> R.string.paso_sustitucion
        "derivamos" -> R.string.paso_derivamos
        "ajuste" -> R.string.paso_ajuste
        "queda" -> R.string.paso_queda
        else -> R.string.paso_volvemos
    }

    private fun siguiente() {
        guardarActual()
        if (indice < preguntas.size - 1) {
            indice++
            mostrarPregunta()
        } else {
            mostrarResumen()
        }
    }

    private fun anterior() {
        guardarActual()
        if (indice > 0) {
            indice--
            mostrarPregunta()
        }
    }

    private fun mostrarResumen() {
        var correctas = 0
        for (i in preguntas.indices) {
            if (Quiz.esCorrecta(preguntas[i], respuestasUsuario[i])) correctas++
        }
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.resultado_titulo))
            .setMessage(getString(R.string.resultado_msg, correctas, preguntas.size))
            .setPositiveButton(getString(R.string.volver_menu)) { _, _ -> finish() }
            .setNegativeButton(getString(R.string.seguir_repasando), null)
            .show()
    }
}
