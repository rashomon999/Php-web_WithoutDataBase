package com.integrales

/**
 * Una pregunta del cuestionario.
 *
 * @param latex       La integral en LaTeX, se renderiza con KaTeX (igual que MathJax en la web).
 *                    Si está vacía, solo se muestra el texto de [enunciado].
 * @param enunciado   Texto adicional arriba de la fórmula (ej. "Propiedad:"). Puede estar vacío.
 * @param aceptadas   Respuestas aceptadas (se comparan sin espacios y sin mayúsculas/minúsculas).
 *                    Incluye las mismas de tu PHP + variantes cómodas para escribir en celular.
 * @param solucion    La solución en LaTeX que se renderiza al pulsar Ver solución.
 */
/**
 * Un paso de la explicación. La clave es un texto traducible (ver QuizActivity)
 * y el latex es la fórmula que se renderiza debajo.
 */
data class Paso(
    val clave: String,
    val latex: String
)

data class Pregunta(
    val latex: String,
    val enunciado: String,
    val aceptadas: List<String>,
    val solucion: String,
    val pasos: List<Paso> = emptyList()   // explicación opcional (se muestra con la solución)
)

object Quiz {

    /** Normaliza lo que escribe el usuario: quita espacios y pasa a minúsculas. */
    fun normalizar(texto: String): String =
        texto.replace(" ", "").replace("·", "").lowercase()

    fun esCorrecta(pregunta: Pregunta, respuestaUsuario: String): Boolean {
        val r = normalizar(respuestaUsuario)
        if (r.isEmpty()) return false

        // 1) Coincidencia exacta con la lista (como en la web)
        if (pregunta.aceptadas.any { normalizar(it) == r }) return true

        // 2) Verificación matemática (estilo Symbolab): acepta cualquier
        //    forma equivalente, ej. \frac{1}{3x^{-3}}+C  ==  \frac{x^3}{3}+C
        val canonica = normalizar(pregunta.solucion)
        return if (canonica.endsWith("+c")) {
            // la constante de integración es obligatoria
            if (!r.endsWith("+c")) false
            else Algebra.equivalentes(r.dropLast(2), canonica.dropLast(2))
        } else {
            Algebra.equivalentes(r, canonica)
        }
    }

    // ============================================================
    // CUESTIONARIO 1: Integrales básicas  (de tu index.php - 19 preguntas)
    // ============================================================
    val basicas = listOf(
        Pregunta(
            "\\int 3 \\, dx",
            "",
            listOf("3x+C"),
            "3x + C"
        ),
        Pregunta(
            "\\int \\frac{4}{3} \\, dx",
            "",
            listOf("\\frac{4}{3}x+C", "(4/3)x+C", "4/3x+C", "4x/3+C"),
            "\\frac{4}{3}x + C"
        ),
        Pregunta(
            "\\int dx",
            "prop",
            listOf("x+C"),
            "x + C"
        ),
        Pregunta(
            "\\int k \\, dx",
            "prop",
            listOf("k\\intdx", "kx+C", "xk+C"),
            "kx + C"
        ),
        Pregunta(
            "\\int x \\, du",
            "",
            listOf("xu+C", "ux+C"),
            "xu + C"
        ),
        Pregunta(
            "\\int x^{n} \\, dx",
            "prop",
            listOf("\\frac{x^{n+1}}{n+1}+C", "x^(n+1)/(n+1)+C", "(x^(n+1))/(n+1)+C"),
            "\\frac{x^{n+1}}{n+1} + C"
        ),
        Pregunta(
            "n \\neq \\; ?",
            "npregunta",
            listOf("n\\neq-1", "n≠-1", "n!=-1", "-1", "ndiferentede-1", "ndistintode-1"),
            "n \\neq -1"
        ),
        Pregunta(
            "\\int x^{3} \\, dx",
            "",
            listOf("\\frac{x^4}{4}+C", "x^4/4+C", "(x^4)/4+C"),
            "\\frac{x^{4}}{4} + C"
        ),
        Pregunta(
            "\\int x^{-3} \\, dx",
            "",
            listOf("\\frac{-1}{2x^2}+C", "-\\frac{1}{2x^2}+C", "-1/2x^2+C", "-1/(2x^2)+C"),
            "\\frac{-1}{2x^{2}} + C"
        ),
        Pregunta(
            "\\int u^{4} \\, dx",
            "",
            listOf("u^4x+C", "xu^4+C"),
            "u^{4}x + C"
        ),
        Pregunta(
            "\\int 3x^{-2} \\, dx",
            "",
            listOf("\\frac{-3}{x}+C", "-3/x+C", "-\\frac{3}{x}+C"),
            "\\frac{-3}{x} + C"
        ),
        Pregunta(
            "\\int \\frac{1}{x^{3}} \\, dx",
            "",
            listOf("\\frac{-1}{2x^2}+C", "-\\frac{1}{2x^2}+C", "-1/2x^2+C", "-1/(2x^2)+C"),
            "\\frac{-1}{2x^{2}} + C"
        ),
        Pregunta(
            "\\int \\frac{dx}{x^{2}}",
            "",
            listOf("\\frac{-1}{x}+C", "-1/x+C", "-\\frac{1}{x}+C"),
            "\\frac{-1}{x} + C"
        ),
        Pregunta(
            "\\int \\frac{3}{x^{4}} \\, dx",
            "",
            listOf("\\frac{-1}{x^3}+C", "-1/x^3+C", "-1/(x^3)+C", "-\\frac{1}{x^3}+C"),
            "\\frac{-1}{x^{3}} + C"
        ),
        Pregunta(
            "\\int \\frac{9 \\, dx}{x^{4}}",
            "",
            listOf("\\frac{-3}{x^3}+C", "-3/x^3+C", "-3/(x^3)+C", "-\\frac{3}{x^3}+C"),
            "\\frac{-3}{x^{3}} + C"
        ),
        Pregunta(
            "\\int \\frac{dx}{x^{-2}}",
            "",
            listOf("\\frac{x^3}{3}+C", "x^3/3+C", "(x^3)/3+C"),
            "\\frac{x^{3}}{3} + C"
        ),
        Pregunta(
            "\\int x^{\\frac{2}{3}} \\, dx",
            "",
            listOf(
                "\\frac{3x^{\\frac{5}{3}}}{5}+C",
                "3x^(5/3)/5+C", "(3x^(5/3))/5+C", "(3/5)x^(5/3)+C"
            ),
            "\\frac{3x^{\\frac{5}{3}}}{5} + C"
        ),
        Pregunta(
            "\\int x^{\\frac{1}{2}} \\, dx",
            "",
            listOf(
                "\\frac{2x^{\\frac{3}{2}}}{3}+C", "\\frac{2x^\\frac{3}{2}}{3}+C",
                "2x^(3/2)/3+C", "(2x^(3/2))/3+C", "(2/3)x^(3/2)+C"
            ),
            "\\frac{2x^{\\frac{3}{2}}}{3} + C"
        ),
        Pregunta(
            "\\int x^{-\\frac{1}{3}} \\, dx",
            "",
            listOf(
                "\\frac{3x^{\\frac{2}{3}}}{2}+C",
                "3x^(2/3)/2+C", "(3x^(2/3))/2+C", "(3/2)x^(2/3)+C"
            ),
            "\\frac{3x^{\\frac{2}{3}}}{2} + C"
        )
    )

    // ============================================================
    // BÁSICAS 2  (de tu segundo.php - 18 preguntas: Ln, raíces y polinomios)
    // ============================================================
    val basicas2 = listOf(
        Pregunta("\\int x^{-1} \\, dx", "",
            listOf("Ln|x|+C"), "Ln|x|+C"),
        Pregunta("\\int \\frac{3}{u} \\, du", "",
            listOf("3Ln|u|+C"), "3Ln|u|+C"),
        Pregunta("\\int \\frac{5}{4x} \\, dx", "",
            listOf("\\frac{5}{4}Ln|x|+C"), "\\frac{5}{4}Ln|x|+C"),
        Pregunta("\\int \\frac{1}{x} \\, dx", "",
            listOf("Ln|x|+C"), "Ln|x|+C"),
        Pregunta("\\int \\frac{\\sqrt{3}}{2x} \\, dx", "",
            listOf("\\frac{\\sqrt{3}}{2}Ln|x|+C"), "\\frac{\\sqrt{3}}{2}Ln|x|+C"),
        Pregunta("\\int \\sqrt{x} \\, dx", "",
            listOf("\\frac{2x^{\\frac{3}{2}}}{3}+C", "\\frac{2\\sqrt{x^3}}{3}+C", "\\frac{2}{3}\\sqrt{x^3}+C"),
            "\\frac{2\\sqrt{x^{3}}}{3}+C"),
        Pregunta("\\int \\sqrt[3]{x^2} \\, dx", "",
            listOf("\\frac{3}{5}\\sqrt[3]{x^5}+C", "\\frac{3x^{5/3}}{5}+C"),
            "\\frac{3x^{5/3}}{5}+C"),
        Pregunta("\\int \\sqrt{3x} \\, dx", "",
            listOf("\\frac{2\\sqrt{3x^3}}{3}+C"), "\\frac{2\\sqrt{3x^3}}{3}+C"),
        Pregunta("\\int \\sqrt{16x} \\, dx", "",
            listOf("\\frac{8}{3}x\\sqrt{x}+C", "\\frac{8}{3}\\sqrt{x^3}+C",
                   "\\frac{8x^{\\frac{3}{2}}}{3}+C", "\\frac{8\\sqrt{x^3}}{3}+C"),
            "\\frac{8x^{\\frac{3}{2}}}{3}+C"),
        Pregunta("\\int \\frac{5}{\\sqrt{x}} \\, dx", "",
            listOf("10\\sqrt{x}+C"), "10\\sqrt{x}+C"),
        Pregunta("\\int \\frac{2}{\\sqrt{x^3}} \\, dx", "",
            listOf("\\frac{-4}{\\sqrt{x}}+C", "\\frac{-4}{x^\\frac{1}{2}}+C"),
            "\\frac{-4}{\\sqrt{x}}+C"),
        Pregunta("\\int (2x^3+5x^2-2x+1) \\, dx", "",
            listOf("\\frac{x^4}{2}+\\frac{5x^3}{3}-x^2+x+C"),
            "\\frac{x^4}{2}+\\frac{5x^3}{3}-x^2+x+C"),
        Pregunta("\\int (x^5-2x^3) \\, dx", "",
            listOf("\\frac{x^6}{6}-\\frac{x^4}{2}+C"),
            "\\frac{x^6}{6}-\\frac{x^4}{2}+C"),
        Pregunta("\\int (3x^4-4x^3+6x^2-\\frac{x}{2}+3) \\, dx", "",
            listOf("\\frac{3x^5}{5}-x^4+2x^3-\\frac{x^2}{4}+3x+C"),
            "\\frac{3x^5}{5}-x^4+2x^3-\\frac{x^2}{4}+3x+C"),
        Pregunta("\\int \\frac{6x^5-12x^4+3x^3}{3x^2} \\, dx", "",
            listOf("\\frac{x^4}{2}-\\frac{4x^3}{3}+\\frac{x^2}{2}+C"),
            "\\frac{x^4}{2}-\\frac{4x^3}{3}+\\frac{x^2}{2}+C"),
        Pregunta("\\int \\frac{8x^3-4x}{6x} \\, dx", "",
            listOf("\\frac{4x^3}{9}-\\frac{2x}{3}+C"),
            "\\frac{4x^3}{9}-\\frac{2x}{3}+C"),
        Pregunta("\\int \\frac{5x^3-3x^2+2}{2x^2} \\, dx", "",
            listOf("\\frac{5x^2}{4}-\\frac{3x}{2}-\\frac{1}{x}+C"),
            "\\frac{5x^2}{4}-\\frac{3x}{2}-\\frac{1}{x}+C"),
        Pregunta("\\int \\frac{5x^3-2x+2}{4x^3} \\, dx", "",
            listOf("\\frac{5x}{4}+\\frac{1}{2x}-\\frac{1}{4x^2}+C"),
            "\\frac{5x}{4}+\\frac{1}{2x}-\\frac{1}{4x^2}+C")
    )

    // ============================================================
    // BÁSICAS 3  (de tu tercero.php - 13 preguntas: productos y u'/u -> Ln)
    // ============================================================
    val basicas3 = listOf(
        Pregunta("\\int 3x^2(2x^2-5) \\, dx", "",
            listOf("\\frac{6x^5}{5}-5x^3+C"), "\\frac{6x^5}{5}-5x^3+C"),
        Pregunta("\\int 2x^3(x^3-2x^2+x+3) \\, dx", "",
            listOf("\\frac{2x^7}{7}-\\frac{2x^6}{3}+\\frac{2x^5}{5}+\\frac{3x^4}{2}+C"),
            "\\frac{2x^7}{7}-\\frac{2x^6}{3}+\\frac{2x^5}{5}+\\frac{3x^4}{2}+C"),
        Pregunta("\\int (2x-5)(3x^2+4x) \\, dx", "",
            listOf("\\frac{3x^4}{2}-\\frac{7x^3}{3}-10x^2+C"),
            "\\frac{3x^4}{2}-\\frac{7x^3}{3}-10x^2+C"),
        Pregunta("\\int (3x^2+5)(x^2-3) \\, dx", "",
            listOf("\\frac{3x^5}{5}-\\frac{4x^3}{3}-15x+C"),
            "\\frac{3x^5}{5}-\\frac{4x^3}{3}-15x+C"),
        Pregunta("\\int (3x-5)^2 \\, dx", "",
            listOf("3x^3-15x^2+25x+C"), "3x^3-15x^2+25x+C"),
        Pregunta("\\int (2x+6)^2 \\, dx", "",
            listOf("\\frac{4}{3}x^3+12x^2+36x+C", "\\frac{4x^3}{3}+12x^2+36x+C"),
            "\\frac{4x^3}{3}+12x^2+36x+C"),
        Pregunta("\\int (3x^2-2x)^2 \\, dx", "",
            listOf("\\frac{9}{5}x^5-3x^4+\\frac{4}{3}x^3+C", "\\frac{9x^5}{5}-3x^4+\\frac{4x^3}{3}+C"),
            "\\frac{9x^5}{5}-3x^4+\\frac{4x^3}{3}+C"),
        Pregunta("\\int \\frac{2x-1}{x^2-x+4} \\, dx", "",
            listOf("Ln|x^2-x+4|+C"), "Ln|x^2-x+4|+C",
            listOf(
                Paso("sustitucion", "u = x^2-x+4"),
                Paso("derivamos", "du = (2x-1)\\,dx"),
                Paso("queda", "\\int \\frac{du}{u} = Ln|u|+C"),
                Paso("volvemos", "Ln|x^2-x+4|+C")
            )),
        Pregunta("\\int \\frac{6x+2}{3x^2+2x} \\, dx", "",
            listOf("Ln|3x^2+2x|+C"), "Ln|3x^2+2x|+C",
            listOf(
                Paso("sustitucion", "u = 3x^2+2x"),
                Paso("derivamos", "du = (6x+2)\\,dx"),
                Paso("queda", "\\int \\frac{du}{u} = Ln|u|+C"),
                Paso("volvemos", "Ln|3x^2+2x|+C")
            )),
        Pregunta("\\int \\frac{6x-5}{3x^2-5x} \\, dx", "",
            listOf("Ln|3x^2-5x|+C"), "Ln|3x^2-5x|+C",
            listOf(
                Paso("sustitucion", "u = 3x^2-5x"),
                Paso("derivamos", "du = (6x-5)\\,dx"),
                Paso("queda", "\\int \\frac{du}{u} = Ln|u|+C"),
                Paso("volvemos", "Ln|3x^2-5x|+C")
            )),
        Pregunta("\\int \\frac{15x^2+4x-7}{5x^3+2x^2-7x+3} \\, dx", "",
            listOf("Ln|5x^3+2x^2-7x+3|+C"), "Ln|5x^3+2x^2-7x+3|+C",
            listOf(
                Paso("sustitucion", "u = 5x^3+2x^2-7x+3"),
                Paso("derivamos", "du = (15x^2+4x-7)\\,dx"),
                Paso("queda", "\\int \\frac{du}{u} = Ln|u|+C"),
                Paso("volvemos", "Ln|5x^3+2x^2-7x+3|+C")
            )),
        Pregunta("\\int \\frac{x}{2x^2-5} \\, dx", "",
            listOf("\\frac{1}{4}Ln|2x^2-5|+C"), "\\frac{1}{4}Ln|2x^2-5|+C",
            listOf(
                Paso("sustitucion", "u = 2x^2-5"),
                Paso("derivamos", "du = 4x\\,dx"),
                Paso("ajuste", "x\\,dx = \\frac{du}{4}"),
                Paso("queda", "\\frac{1}{4}\\int \\frac{du}{u} = \\frac{1}{4}Ln|u|+C"),
                Paso("volvemos", "\\frac{1}{4}Ln|2x^2-5|+C")
            )),
        Pregunta("\\int \\frac{x}{3x^2+2} \\, dx", "",
            listOf("\\frac{1}{6}Ln|3x^2+2|+C"), "\\frac{1}{6}Ln|3x^2+2|+C",
            listOf(
                Paso("sustitucion", "u = 3x^2+2"),
                Paso("derivamos", "du = 6x\\,dx"),
                Paso("ajuste", "x\\,dx = \\frac{du}{6}"),
                Paso("queda", "\\frac{1}{6}\\int \\frac{du}{u} = \\frac{1}{6}Ln|u|+C"),
                Paso("volvemos", "\\frac{1}{6}Ln|3x^2+2|+C")
            ))
    )

    // ============================================================
    // BÁSICAS 4  (de tu cuarto.php - 17 preguntas: sustitución)
    // ============================================================
    val basicas4 = listOf(
        Pregunta("\\int \\frac{3x}{6x^2+9} \\, dx", "",
            listOf("\\frac{1}{4}Ln|6x^2+9|+C"), "\\frac{1}{4}Ln|6x^2+9|+C",
            listOf(
                Paso("sustitucion", "u = 6x^2+9"),
                Paso("derivamos", "du = 12x\\,dx"),
                Paso("ajuste", "3x\\,dx = \\frac{du}{4}"),
                Paso("queda", "\\frac{1}{4}\\int \\frac{du}{u} = \\frac{1}{4}Ln|u|+C"),
                Paso("volvemos", "\\frac{1}{4}Ln|6x^2+9|+C")
            )),
        Pregunta("\\int \\frac{4x}{5x^2-3} \\, dx", "",
            listOf("\\frac{2}{5}Ln|5x^2-3|+C"), "\\frac{2}{5}Ln|5x^2-3|+C",
            listOf(
                Paso("sustitucion", "u = 5x^2-3"),
                Paso("derivamos", "du = 10x\\,dx"),
                Paso("ajuste", "4x\\,dx = \\frac{2}{5}\\,du"),
                Paso("queda", "\\frac{2}{5}\\int \\frac{du}{u} = \\frac{2}{5}Ln|u|+C"),
                Paso("volvemos", "\\frac{2}{5}Ln|5x^2-3|+C")
            )),
        Pregunta("\\int \\frac{3x^2-x}{4x^3-2x^2} \\, dx", "",
            listOf("\\frac{1}{4}Ln|4x^3-2x^2|+C"), "\\frac{1}{4}Ln|4x^3-2x^2|+C",
            listOf(
                Paso("sustitucion", "u = 4x^3-2x^2"),
                Paso("derivamos", "du = (12x^2-4x)\\,dx = 4(3x^2-x)\\,dx"),
                Paso("ajuste", "(3x^2-x)\\,dx = \\frac{du}{4}"),
                Paso("queda", "\\frac{1}{4}\\int \\frac{du}{u} = \\frac{1}{4}Ln|u|+C"),
                Paso("volvemos", "\\frac{1}{4}Ln|4x^3-2x^2|+C")
            )),
        Pregunta("\\int \\frac{x+5}{x-8} \\, dx", "",
            listOf("x-8+13Ln|x-8|+C", "x+13Ln|x-8|+C"),
            "x+13Ln|x-8|+C"),
        Pregunta("\\int \\frac{x-3}{x+4} \\, dx", "",
            listOf("x+4-7Ln|x+4|+C", "x-7Ln|x+4|+C"),
            "x-7Ln|x+4|+C"),
        Pregunta("\\int 2x(x^2-5)^4 \\, dx", "",
            listOf("\\frac{(x^2-5)^5}{5}+C", "\\frac{1}{5}(x^2-5)^5+C"),
            "\\frac{(x^2-5)^5}{5}+C"),
        Pregunta("\\int (x+4)^3 \\, dx", "",
            listOf("\\frac{(x+4)^4}{4}+C"), "\\frac{(x+4)^4}{4}+C"),
        Pregunta("\\int 6x(3x^2-2)^4 \\, dx", "",
            listOf("\\frac{(3x^2-2)^5}{5}+C"), "\\frac{(3x^2-2)^5}{5}+C"),
        Pregunta("\\int x^2(2x^3-5)^4 \\, dx", "",
            listOf("\\frac{(2x^3-5)^5}{30}+C", "\\frac{1}{30}(2x^3-5)^5+C"),
            "\\frac{(2x^3-5)^5}{30}+C"),
        Pregunta("\\int 2t^3(t^4-3)^5 \\, dt", "",
            listOf("\\frac{(t^4-3)^6}{12}+C"), "\\frac{(t^4-3)^6}{12}+C"),
        Pregunta("\\int (3x+1)(3x^2+2x)^6 \\, dx", "",
            listOf("\\frac{(3x^2+2x)^7}{14}+C"), "\\frac{(3x^2+2x)^7}{14}+C"),
        Pregunta("\\int 3x^2 \\sqrt{x^3+5} \\, dx", "",
            listOf("\\frac{2\\sqrt{(x^3+5)^3}}{3}+C"), "\\frac{2\\sqrt{(x^3+5)^3}}{3}+C"),
        Pregunta("\\int 8x^3 \\sqrt{2x^4+6} \\, dx", "",
            listOf("\\frac{2\\sqrt{(2x^4+6)^3}}{3}+C"), "\\frac{2\\sqrt{(2x^4+6)^3}}{3}+C"),
        Pregunta("\\int 2x \\, \\sqrt[3]{x^2-5} \\, dx", "",
            listOf("\\frac{3\\sqrt[3]{(x^2-5)^4}}{4}+C"),
            "\\frac{3(x^2-5)^{\\frac{4}{3}}}{4}+C"),
        Pregunta("\\int x \\, \\sqrt{3x^2-6} \\, dx", "",
            listOf("\\frac{1\\sqrt{(3x^2-6)^3}}{9}+C", "\\frac{\\sqrt{(3x^2-6)^3}}{9}+C"),
            "\\frac{\\sqrt{(3x^2-6)^3}}{9}+C"),
        Pregunta("\\int 2x^3 \\, \\sqrt{x^4+2} \\, dx", "",
            listOf("\\frac{1\\sqrt{(x^4+2)^3}}{3}+C", "\\frac{\\sqrt{(x^4+2)^3}}{3}+C"),
            "\\frac{\\sqrt{(x^4+2)^3}}{3}+C"),
        Pregunta("\\int 4x^2 \\, \\sqrt{(5x^3-3)^5} \\, dx", "",
            listOf("\\frac{8\\sqrt{(5x^3-3)^7}}{105}+C"), "\\frac{8\\sqrt{(5x^3-3)^7}}{105}+C")
    )

    // ============================================================
    // BÁSICAS 5  (de tu quinto.php - 19 preguntas: exponenciales y Ln)
    // ============================================================
    val basicas5 = listOf(
        Pregunta("\\int (6x-5) \\sqrt{(9x^2-15x)^3} \\, dx", "",
            listOf("\\frac{2\\sqrt{(9x^2-15x)^5}}{15}+C"), "\\frac{2\\sqrt{(9x^2-15x)^5}}{15}+C"),
        Pregunta("\\int x^3 \\sqrt{x^2-1} \\, dx", "",
            listOf("\\frac{\\sqrt{(x^2-1)^5}}{5}+\\frac{\\sqrt{(x^2-1)^3}}{3}+C",
                   "\\frac{1}{5}\\sqrt{(x^2-1)^5}+\\frac{1}{3}\\sqrt{(x^2-1)^3}+C",
                   "\\frac{1(x^2-1)^\\frac{5}{2}}{5}+\\frac{1(x^2-1)^\\frac{3}{2}}{3}+C"),
            "\\frac{\\sqrt{(x^2-1)^5}}{5}+\\frac{\\sqrt{(x^2-1)^3}}{3}+C"),
        Pregunta("\\int 6x^5(x^3-3)^6 \\, dx", "",
            listOf("\\frac{(x^3-3)^8}{4}+\\frac{6(x^3-3)^7}{7}+C"),
            "\\frac{(x^3-3)^8}{4}+\\frac{6(x^3-3)^7}{7}+C"),
        Pregunta("\\int \\frac{2x}{\\sqrt{x^2+3}} \\, dx", "",
            listOf("2\\sqrt{x^2+3}+C"), "2\\sqrt{x^2+3}+C"),
        Pregunta("\\int \\frac{6x+5}{\\sqrt[3]{3x^2+5x}} \\, dx", "",
            listOf("\\frac{3\\sqrt[3]{(3x^2+5x)^2}}{2}+C", "\\frac{3}{2}\\sqrt[3]{(3x^2+5x)^2}+C"),
            "\\frac{3(3x^2+5x)^{\\frac{2}{3}}}{2}+C"),
        Pregunta("\\int 3^x \\, dx", "",
            listOf("\\frac{3^x}{Ln3}+C"), "\\frac{3^x}{Ln3}+C"),
        Pregunta("\\int 2^{3x} \\, dx", "",
            listOf("\\frac{2^{3x}}{Ln8}+C", "\\frac{2^{3x}}{3Ln2}+C"),
            "\\frac{2^{3x}}{3Ln2}+C"),
        Pregunta("\\int 3^{2x} \\, dx", "",
            listOf("\\frac{3^{2x}}{Ln9}+C", "\\frac{3^{2x}}{2Ln3}+C"),
            "\\frac{3^{2x}}{2Ln3}+C"),
        Pregunta("\\int 6x \\cdot 6^{3x^2+1} \\, dx", "",
            listOf("\\frac{6^{3x^2+1}}{Ln6}+C"), "\\frac{6^{3x^2+1}}{Ln6}+C"),
        Pregunta("\\int e^{2x} \\, dx", "",
            listOf("\\frac{1}{2}e^{2x}+C", "\\frac{e^{2x}}{2}+C"),
            "\\frac{e^{2x}}{2}+C"),
        Pregunta("\\int e^{5x+3} \\, dx", "",
            listOf("\\frac{1}{5}e^{5x+3}+C"), "\\frac{1}{5}e^{5x+3}+C"),
        Pregunta("\\int 6\\,e^{3x} \\, dx", "",
            listOf("2e^{3x}+C"), "2e^{3x}+C"),
        Pregunta("\\int \\frac{e^{5x}}{2} \\, dx", "",
            listOf("\\frac{1}{10}e^{5x}+C"), "\\frac{1}{10}e^{5x}+C"),
        Pregunta("\\int x\\,e^{x^2} \\, dx", "",
            listOf("\\frac{1}{2}e^{x^2}+C"), "\\frac{1}{2}e^{x^2}+C"),
        Pregunta("\\int t\\,e^{t^2} \\, dt", "",
            listOf("\\frac{1}{2}e^{t^2}+C"), "\\frac{1}{2}e^{t^2}+C"),
        Pregunta("\\int 2x^2\\,e^{2x^3} \\, dx", "",
            listOf("\\frac{1}{3}e^{2x^3}+C"), "\\frac{1}{3}e^{2x^3}+C"),
        Pregunta("\\int \\frac{Ln\\,x}{x} \\, dx", "",
            listOf("\\frac{(Lnx)^2}{2}+C", "\\frac{Ln^2x}{2}+C"),
            "\\frac{(Lnx)^2}{2}+C"),
        Pregunta("\\int \\frac{Ln\\,x^2}{3x} \\, dx", "",
            listOf("\\frac{Ln^2x}{3}+C", "\\frac{1}{3}Ln^2x+C"),
            "\\frac{(Lnx)^2}{3}+C"),
        Pregunta("\\int \\frac{dx}{x\\,Ln\\,x}", "",
            listOf("Ln|Lnx|+C", "Ln|Ln(x)|+C"),
            "Ln|Lnx|+C")
    )

    // ============================================================
    // CUESTIONARIO TRIG: Integrales trigonométricas (de tu trigonometricas.php - 10 preguntas)
    // ============================================================
    val trigonometricas = listOf(
        Pregunta(
            "\\int \\sin x \\, dx",
            "",
            listOf("-Cosx+C", "-Cos(x)+C"),
            "-\\cos x + C"
        ),
        Pregunta(
            "\\int \\cos x \\, dx",
            "",
            listOf("Sinx+C", "Senx+C", "Sin(x)+C", "Sen(x)+C"),
            "\\sin x + C"
        ),
        Pregunta(
            "\\int \\sec^2 x \\, dx",
            "",
            listOf("Tanx+C", "Tan(x)+C"),
            "\\tan x + C"
        ),
        Pregunta(
            "\\int \\csc^2 x \\, dx",
            "",
            listOf("-Cotx+C", "-Cot(x)+C"),
            "-\\cot x + C"
        ),
        Pregunta(
            "\\int \\sec x \\tan x \\, dx",
            "",
            listOf("Secx+C", "Sec(x)+C"),
            "\\sec x + C"
        ),
        Pregunta(
            "\\int \\csc x \\cot x \\, dx",
            "",
            listOf("-Cscx+C", "-Csc(x)+C"),
            "-\\csc x + C"
        ),
        Pregunta(
            "\\int \\tan x \\, dx",
            "",
            listOf("Ln|Secx|+C", "Ln|Sec(x)|+C"),
            "\\ln|\\sec x| + C"
        ),
        Pregunta(
            "\\int \\cot x \\, dx",
            "",
            listOf("Ln|Senx|+C", "Ln|Sinx|+C", "Ln|Sen(x)|+C", "Ln|Sin(x)|+C"),
            "\\ln|\\sin x| + C"
        ),
        Pregunta(
            "\\int \\sec x \\, dx",
            "",
            listOf("Ln|Secx+Tanx|+C", "Ln|Sec(x)+Tan(x)|+C"),
            "\\ln|\\sec x + \\tan x| + C"
        ),
        Pregunta(
            "\\int \\csc x \\, dx",
            "",
            listOf("-Ln|Cscx+Cotx|+C", "-Ln|Csc(x)+Cot(x)|+C"),
            "-\\ln|\\csc x + \\cot x| + C"
        )
    )

    fun obtener(nombre: String): List<Pregunta> = when (nombre) {
        "b2" -> basicas2
        "b3" -> basicas3
        "b4" -> basicas4
        "b5" -> basicas5
        "trig" -> trigonometricas
        else -> basicas
    }

}
